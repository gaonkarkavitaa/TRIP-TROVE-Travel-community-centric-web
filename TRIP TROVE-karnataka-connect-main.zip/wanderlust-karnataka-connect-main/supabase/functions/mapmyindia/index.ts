
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const MAPMYINDIA_API_KEY = "372586837566fa6c155dc7472ba83f33";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const url = new URL(req.url);
    const endpoint = url.searchParams.get("endpoint") || "map";
    const place = url.searchParams.get("place") || "Karnataka";
    
    let apiUrl = "";
    
    if (endpoint === "places") {
      apiUrl = `https://apis.mapmyindia.com/advancedmaps/v1/${MAPMYINDIA_API_KEY}/geo_code?address=${encodeURIComponent(place)}`;
    } else if (endpoint === "distance") {
      const start = url.searchParams.get("start") || "";
      const end = url.searchParams.get("end") || "";
      apiUrl = `https://apis.mapmyindia.com/advancedmaps/v1/${MAPMYINDIA_API_KEY}/distance_matrix/driving/${start};${end}`;
    } else if (endpoint === "autocomplete") {
      const query = url.searchParams.get("query") || "";
      apiUrl = `https://apis.mapmyindia.com/advancedmaps/v1/${MAPMYINDIA_API_KEY}/autosuggest?q=${encodeURIComponent(query)}`;
    } else if (endpoint === "nearby") {
      const lng = url.searchParams.get("lng") || "";
      const lat = url.searchParams.get("lat") || "";
      const keyword = url.searchParams.get("keyword") || "tourist";
      apiUrl = `https://apis.mapmyindia.com/advancedmaps/v1/${MAPMYINDIA_API_KEY}/nearby/${lng}/${lat}?keywords=${encodeURIComponent(keyword)}`;
    } else {
      // Default map endpoint
      apiUrl = `https://apis.mapmyindia.com/advancedmaps/v1/${MAPMYINDIA_API_KEY}/map_center?place=${encodeURIComponent(place)}`;
    }
    
    console.log(`Calling MapMyIndia API: ${apiUrl}`);
    
    const response = await fetch(apiUrl);
    const data = await response.json();
    
    // Return the API response
    return new Response(
      JSON.stringify(data),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  } catch (error) {
    console.error(`Error in MapMyIndia edge function:`, error);
    
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  }
});
