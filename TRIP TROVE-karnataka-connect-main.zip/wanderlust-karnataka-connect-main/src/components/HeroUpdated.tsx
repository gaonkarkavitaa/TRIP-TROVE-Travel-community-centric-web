
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useAuth } from "@/hooks/useAuth";

const HeroUpdated = () => {
  const { user } = useAuth();

  return (
    <div className="relative overflow-hidden">
      {/* Hero background image with enhanced styling - Rich heritage of Karnataka */}
      <div className="absolute inset-0 z-0">
        <img 
          src="/lovable-uploads/e3d56d66-2a94-42d3-89f0-38e244df72eb.png" 
          alt="Karnataka Heritage Collage" 
          className="w-full h-full object-cover transform scale-105 animate-slow-zoom"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.onerror = null;
            target.src = "https://karnatakatourism.org/wp-content/uploads/2020/05/hampi-2.jpg"; // Fallback image showing Hampi ruins
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-black/50"></div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-amber-600 blur-[100px]"></div>
        <div className="absolute top-1/3 right-1/3 w-80 h-80 rounded-full bg-triptrove-terracotta blur-[120px]"></div>
      </div>
      
      {/* Hero content with enhanced animations */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="relative z-10 container mx-auto px-4 py-32 md:py-44 flex flex-col items-center text-center"
      >
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-5xl md:text-7xl font-bold text-white mb-6"
        >
          Discover <span className="bg-gradient-to-r from-triptrove-yellow via-amber-500 to-triptrove-gold bg-clip-text text-transparent">Karnataka's Rich Heritage</span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-xl md:text-2xl text-white max-w-3xl mb-10 leading-relaxed"
        >
          From the ancient ruins of Hampi to the royal palaces of Mysore, explore the land of 
          magnificent monuments, vibrant traditions, and cultural marvels that span centuries.
        </motion.p>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          {user ? (
            <>
              <Link to="/user-dashboard">
                <Button size="lg" className="bg-gradient-to-r from-triptrove-blue to-blue-600 hover:from-triptrove-blue/90 hover:to-blue-700 text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
                  Your Dashboard
                </Button>
              </Link>
              <Link to="/explore">
                <Button size="lg" variant="outline" className="bg-transparent text-white border-white hover:bg-white/30 text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
                  Explore Karnataka
                </Button>
              </Link>
            </>
          ) : (
            <>
              <Link to="/auth">
                <Button size="lg" className="bg-gradient-to-r from-triptrove-blue to-blue-600 hover:from-triptrove-blue/90 hover:to-blue-700 text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
                  Start Your Journey
                </Button>
              </Link>
              <Link to="/explore">
                <Button size="lg" variant="outline" className="bg-transparent text-white border-white hover:bg-white/30 text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
                  Explore Karnataka
                </Button>
              </Link>
            </>
          )}
        </motion.div>
      </motion.div>
      
      {/* Bottom decorative element */}
      <div className="absolute bottom-0 left-0 w-full">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 120" className="w-full h-16 text-background">
          <path fill="currentColor" fillOpacity="1" d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z"></path>
        </svg>
      </div>
    </div>
  );
};

export default HeroUpdated;
