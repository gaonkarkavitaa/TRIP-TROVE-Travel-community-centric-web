
import { useEffect, useState } from "react";
import { MapPin, LocateFixed, Trash } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";
import { karnatakaTouristSpots } from "@/data/karnataka-data";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import MapBox from "./MapBox";

// Mock function for route optimization
const optimizeRoute = (places: string[]): string[] => {
  // This is a placeholder - in a real app, this would use an algorithm
  // like Dijkstra's or A* to find the optimal route
  return [...places]; // Return the same order for now
};

// Mock function to calculate distance between places
const calculateDistance = (place1: string, place2: string): number => {
  // This is a placeholder - in a real app, this would use actual coordinates
  // and distance calculation formulas
  return Math.floor(Math.random() * 300) + 50; // Random distance between 50-350 km
};

// Mock function to estimate travel times
const estimateTravelTime = (distance: number, mode: string): number => {
  // This is a placeholder - in a real app, this would use actual calculation
  // based on mode of transport and route conditions
  switch(mode) {
    case 'car':
      return Math.round(distance / 60); // Average 60 km/h
    case 'bus':
      return Math.round(distance / 40); // Average 40 km/h
    case 'train':
      return Math.round(distance / 80); // Average 80 km/h
    default:
      return Math.round(distance / 50); // Default average
  }
};

const InteractiveMap = () => {
  const { user } = useAuth();
  const [selectedPlaces, setSelectedPlaces] = useState<string[]>([]);
  const [optimizedRoute, setOptimizedRoute] = useState<string[]>([]);
  const [totalDistance, setTotalDistance] = useState(0);
  const [transportMode, setTransportMode] = useState<'car' | 'bus' | 'train'>('car');
  const [tripName, setTripName] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const handlePlaceSelect = (place: string) => {
    if (selectedPlaces.includes(place)) {
      toast.info(`${place} is already in your itinerary`);
      return;
    }
    
    if (selectedPlaces.length >= 10) {
      toast.warning("You can select up to 10 places for one trip");
      return;
    }
    
    setSelectedPlaces([...selectedPlaces, place]);
    toast.success(`Added ${place} to your itinerary`);
  };

  const handleRemovePlace = (place: string) => {
    setSelectedPlaces(selectedPlaces.filter(p => p !== place));
    toast.info(`Removed ${place} from your itinerary`);
  };

  const handleOptimizeRoute = () => {
    if (selectedPlaces.length < 2) {
      toast.warning("Please select at least 2 places to optimize a route");
      return;
    }
    
    const optimized = optimizeRoute(selectedPlaces);
    setOptimizedRoute(optimized);
    
    // Calculate total distance
    let totalDist = 0;
    for (let i = 0; i < optimized.length - 1; i++) {
      totalDist += calculateDistance(optimized[i], optimized[i + 1]);
    }
    setTotalDistance(totalDist);
    
    toast.success("Route optimized!", {
      description: `The best route has been calculated with a total distance of ${totalDist} km.`
    });
  };

  const handleClearSelection = () => {
    setSelectedPlaces([]);
    setOptimizedRoute([]);
    setTotalDistance(0);
    setTripName("");
    toast.info("Itinerary cleared");
  };
  
  const handleSaveTrip = async () => {
    if (!user) {
      toast.error("Please sign in to save your trip");
      return;
    }
    
    if (selectedPlaces.length < 2) {
      toast.error("Please select at least 2 places for your trip");
      return;
    }
    
    if (!tripName.trim()) {
      toast.error("Please enter a name for your trip");
      return;
    }
    
    setIsSaving(true);
    
    try {
      // Fix TypeScript error by using the correct table name and type
      const { error } = await supabase
        .from('saved_trips')
        .insert({
          user_id: user.id,
          name: tripName,
          places: selectedPlaces,
          transport_mode: transportMode,
          total_distance: totalDistance || null
        });
      
      if (error) throw error;
      
      toast.success("Trip saved successfully!");
      
    } catch (error: any) {
      toast.error(error.message || "Failed to save trip");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardTitle className="text-2xl flex items-center">
              <MapPin className="mr-2 h-5 w-5 text-triptrove-blue" />
              Explore Karnataka
            </CardTitle>
          </CardHeader>
          <CardContent>
            <MapBox 
              selectedLocations={selectedPlaces}
              onLocationSelect={handlePlaceSelect}
            />
            
            <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {karnatakaTouristSpots.map((place) => (
                <Button
                  key={place}
                  variant="outline"
                  className={`text-sm justify-start ${selectedPlaces.includes(place) ? 'border-triptrove-blue bg-triptrove-blue/5' : ''}`}
                  onClick={() => handlePlaceSelect(place)}
                >
                  {place}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div>
        <Card className="h-full">
          <CardHeader className="pb-2">
            <CardTitle className="flex justify-between items-center">
              <span className="text-xl">Your Itinerary</span>
              {selectedPlaces.length > 0 && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-destructive"
                  onClick={handleClearSelection}
                >
                  <Trash className="h-4 w-4 mr-2" />
                  Clear
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedPlaces.length === 0 ? (
              <div className="bg-muted/50 rounded-lg p-6 text-center">
                <p className="text-muted-foreground">
                  Select places from the map to add to your itinerary.
                </p>
              </div>
            ) : (
              <>
                <div className="space-y-2 mb-4">
                  <p className="text-sm font-medium">Selected Places ({selectedPlaces.length}):</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedPlaces.map((place) => (
                      <Badge 
                        key={place} 
                        variant="secondary" 
                        className="pl-3 pr-2 py-1.5 flex items-center"
                      >
                        {place}
                        <button 
                          className="ml-1 hover:text-destructive" 
                          onClick={() => handleRemovePlace(place)}
                        >
                          ×
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <Button 
                  className="w-full bg-triptrove-blue hover:bg-triptrove-blue/90 mb-4" 
                  onClick={handleOptimizeRoute}
                >
                  Optimize Route
                </Button>
                
                {user && (
                  <div className="mb-4 space-y-2">
                    <input
                      type="text"
                      placeholder="Enter a name for your trip"
                      className="w-full px-3 py-2 border rounded"
                      value={tripName}
                      onChange={(e) => setTripName(e.target.value)}
                    />
                    <Button
                      variant="outline"
                      className="w-full border-triptrove-blue text-triptrove-blue"
                      onClick={handleSaveTrip}
                      disabled={isSaving}
                    >
                      {isSaving ? "Saving..." : "Save Trip"}
                    </Button>
                  </div>
                )}
                
                {optimizedRoute.length > 0 && (
                  <div className="space-y-4 mt-4">
                    <Separator />
                    <div>
                      <p className="text-sm font-medium mb-2">Optimized Route:</p>
                      <ol className="space-y-2">
                        {optimizedRoute.map((place, index) => (
                          <li 
                            key={place} 
                            className="flex items-center"
                          >
                            <span className="bg-triptrove-blue text-white rounded-full h-6 w-6 flex items-center justify-center mr-2 text-xs">
                              {index + 1}
                            </span>
                            <span>{place}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium">Total Distance:</p>
                      <p className="text-2xl font-semibold text-triptrove-blue">
                        {totalDistance} km
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-2">Estimated Travel Time:</p>
                      <div className="grid grid-cols-3 gap-2">
                        <Button 
                          variant={transportMode === 'car' ? 'default' : 'outline'} 
                          size="sm" 
                          onClick={() => setTransportMode('car')}
                          className={transportMode === 'car' ? 'bg-triptrove-blue' : ''}
                        >
                          Car
                        </Button>
                        <Button 
                          variant={transportMode === 'bus' ? 'default' : 'outline'} 
                          size="sm" 
                          onClick={() => setTransportMode('bus')}
                          className={transportMode === 'bus' ? 'bg-triptrove-blue' : ''}
                        >
                          Bus
                        </Button>
                        <Button 
                          variant={transportMode === 'train' ? 'default' : 'outline'} 
                          size="sm" 
                          onClick={() => setTransportMode('train')}
                          className={transportMode === 'train' ? 'bg-triptrove-blue' : ''}
                        >
                          Train
                        </Button>
                      </div>
                      <div className="mt-2">
                        <Alert>
                          <AlertDescription>
                            Estimated time: <span className="font-bold">{estimateTravelTime(totalDistance, transportMode)} hours</span>
                          </AlertDescription>
                        </Alert>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InteractiveMap;
