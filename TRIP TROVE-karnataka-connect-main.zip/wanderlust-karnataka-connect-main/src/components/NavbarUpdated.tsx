
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Menu, X, User, LogOut, MapPin, School, Map, BookOpen, MessageSquare } from "lucide-react";

const NavbarUpdated = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/auth");
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2">
            <MapPin className="h-6 w-6 text-triptrove-blue" />
            <span className="text-xl font-bold text-triptrove-blue">Trip Trove</span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <NavigationMenu className="hidden md:flex">
          <NavigationMenuList>
            <NavigationMenuItem>
              <Link to="/">
                <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                  Home
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>
            
            <NavigationMenuItem>
              <NavigationMenuTrigger>Explore</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid gap-3 p-4 w-[400px]">
                  <Link to="/" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                    <Map className="h-4 w-4 text-triptrove-blue" />
                    <div>
                      <div className="text-sm font-medium">Interactive Map</div>
                      <div className="text-xs text-muted-foreground">Plan your route across Karnataka</div>
                    </div>
                  </Link>
                  <Link to="/school-trip-planner" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                    <School className="h-4 w-4 text-triptrove-terracotta" />
                    <div>
                      <div className="text-sm font-medium">School Trips</div>
                      <div className="text-xs text-muted-foreground">Plan educational excursions</div>
                    </div>
                  </Link>
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>
            
            <NavigationMenuItem>
              <NavigationMenuTrigger>Community</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid gap-3 p-4 w-[400px]">
                  <Link to="/" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                    <BookOpen className="h-4 w-4 text-triptrove-green" />
                    <div>
                      <div className="text-sm font-medium">Travel Stories</div>
                      <div className="text-xs text-muted-foreground">Read and share experiences</div>
                    </div>
                  </Link>
                  <Link to="/" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                    <MessageSquare className="h-4 w-4 text-triptrove-gold" />
                    <div>
                      <div className="text-sm font-medium">Forums</div>
                      <div className="text-xs text-muted-foreground">Connect with fellow travelers</div>
                    </div>
                  </Link>
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>

        {/* Auth Actions */}
        <div className="hidden md:flex items-center gap-4">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="" alt={user.email || ""} />
                    <AvatarFallback className="bg-triptrove-blue text-white">
                      {user.email ? user.email[0].toUpperCase() : "U"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuItem className="font-normal">
                  <User className="mr-2 h-4 w-4" />
                  <span>{user.email}</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button variant="ghost" onClick={() => navigate("/auth")}>
                Sign In
              </Button>
              <Button className="bg-triptrove-blue hover:bg-triptrove-blue/90" onClick={() => navigate("/auth?tab=signup")}>
                Sign Up
              </Button>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={toggleMobileMenu}>
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden">
          <div className="container py-4 space-y-4 bg-white">
            <Link to="/" onClick={closeMobileMenu} className="block px-2 py-2 hover:bg-slate-100 rounded">
              Home
            </Link>
            <div className="px-2 py-2">
              <div className="font-medium">Explore</div>
              <div className="pl-4 space-y-2 mt-2">
                <Link to="/" onClick={closeMobileMenu} className="block py-1 hover:text-triptrove-blue">
                  Interactive Map
                </Link>
                <Link to="/school-trip-planner" onClick={closeMobileMenu} className="block py-1 hover:text-triptrove-blue">
                  School Trips
                </Link>
              </div>
            </div>
            <div className="px-2 py-2">
              <div className="font-medium">Community</div>
              <div className="pl-4 space-y-2 mt-2">
                <Link to="/" onClick={closeMobileMenu} className="block py-1 hover:text-triptrove-blue">
                  Travel Stories
                </Link>
                <Link to="/" onClick={closeMobileMenu} className="block py-1 hover:text-triptrove-blue">
                  Forums
                </Link>
              </div>
            </div>
            
            <div className="pt-2 border-t">
              {user ? (
                <div className="space-y-2">
                  <div className="px-2 py-2 flex items-center">
                    <Avatar className="h-8 w-8 mr-2">
                      <AvatarFallback className="bg-triptrove-blue text-white">
                        {user.email ? user.email[0].toUpperCase() : "U"}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm truncate">{user.email}</span>
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={handleSignOut}
                  >
                    <LogOut className="mr-2 h-4 w-4" />
                    Log out
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={() => { navigate("/auth"); closeMobileMenu(); }}
                  >
                    Sign In
                  </Button>
                  <Button 
                    className="w-full bg-triptrove-blue hover:bg-triptrove-blue/90" 
                    onClick={() => { navigate("/auth?tab=signup"); closeMobileMenu(); }}
                  >
                    Sign Up
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default NavbarUpdated;
