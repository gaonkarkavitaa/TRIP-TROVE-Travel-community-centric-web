
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { CalendarIcon, MapPin, User } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';

const TravelStories = () => {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchPosts() {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('blogs')
          .select(`
            *,
            profiles:user_id (username, avatar_url, full_name)
          `)
          .order('created_at', { ascending: false })
          .limit(6);
        
        if (error) {
          console.error('Error fetching posts:', error);
          toast.error('Failed to load travel stories');
          return;
        }
        
        setPosts(data || []);
      } catch (error) {
        console.error('Error:', error);
        toast.error('Something went wrong while loading stories');
      } finally {
        setLoading(false);
      }
    }
    
    fetchPosts();
  }, []);
  
  const getInitials = (name: string) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleViewDetails = (postId: string) => {
    navigate(`/post/${postId}`);
  };

  return (
    <div className="container mx-auto px-4">
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="hover:shadow-lg transition-shadow duration-200">
              <CardHeader className="space-y-1 pb-3">
                <div className="h-4 bg-gray-200 rounded w-3/4 animate-pulse"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2 animate-pulse"></div>
              </CardHeader>
              <div className="px-6 pb-2">
                <div className="h-32 bg-gray-200 rounded animate-pulse"></div>
              </div>
              <CardContent>
                <div className="h-4 bg-gray-200 rounded w-full mb-2 animate-pulse"></div>
                <div className="h-4 bg-gray-200 rounded w-5/6 animate-pulse"></div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <div className="flex items-center space-x-2">
                  <div className="h-8 w-8 bg-gray-200 rounded-full animate-pulse"></div>
                  <div className="h-3 bg-gray-200 rounded w-20 animate-pulse"></div>
                </div>
                <div className="h-8 bg-gray-200 rounded w-24 animate-pulse"></div>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : posts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {posts.map((post) => (
            <Card key={post.id} className="hover:shadow-lg transition-shadow duration-200 border border-gray-200">
              <CardHeader className="space-y-1 pb-3">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl line-clamp-1">{post.title}</CardTitle>
                  <Badge variant="outline" className="bg-blue-50">
                    {post.location || 'Karnataka'}
                  </Badge>
                </div>
                <CardDescription className="flex items-center gap-1">
                  <CalendarIcon className="w-4 h-4" /> 
                  {formatDate(post.created_at)}
                </CardDescription>
              </CardHeader>
              
              {post.cover_image && (
                <div className="px-6 pb-2">
                  <img 
                    src={post.cover_image} 
                    alt={post.title} 
                    className="w-full h-48 object-cover rounded"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.onerror = null;
                      target.src = 'https://source.unsplash.com/random/300x200/?karnataka,india';
                    }}
                  />
                </div>
              )}
              
              <CardContent>
                <p className="text-gray-600 line-clamp-3">
                  {post.content}
                </p>
                {post.location && (
                  <div className="flex items-center mt-2 text-sm text-gray-500">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{post.location}</span>
                  </div>
                )}
              </CardContent>
              
              <CardFooter className="flex justify-between border-t pt-4">
                <div className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage 
                      src={post.profiles?.avatar_url} 
                      alt={post.profiles?.username || 'User'} 
                    />
                    <AvatarFallback>{getInitials(post.profiles?.full_name || post.profiles?.username || 'User')}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm text-gray-600">
                    {post.profiles?.username || 'Anonymous'}
                  </span>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleViewDetails(post.id)}
                >
                  View Details
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
          <div className="mb-4 flex justify-center">
            <User className="h-12 w-12 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-1">No travel stories yet</h3>
          <p className="text-gray-500 mb-4">Be the first to share your Karnataka travel experience!</p>
          <Button onClick={() => navigate('/create-post')}>
            Create a Travel Story
          </Button>
        </div>
      )}
      
      <div className="text-center mt-10">
        <Button onClick={() => navigate('/community')} className="px-6">
          View All Stories
        </Button>
      </div>
    </div>
  );
};

export default TravelStories;
