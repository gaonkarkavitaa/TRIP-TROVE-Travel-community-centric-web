
import { ArrowRight, Info } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

// Featured places data with verified Karnataka tourism images and descriptions
const featuredPlaces = [
  {
    id: 1,
    name: "Hampi",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/05/Hampi.jpg",
    fallbackImage: "https://www.karnatakatourism.org/wp-content/uploads/2020/06/hampi-stone-chariot.jpg",
    description: "Ancient ruins of the Vijayanagara Empire with magnificent stone temples and monuments.",
    rating: 4.9,
    detailedInfo: "Hampi was the capital of the Vijayanagara Empire in the 14th century and is a UNESCO World Heritage Site. The ruins spread over an area of more than 25 square kilometers, including beautiful temples, palaces, market streets, and monolithic sculptures. The architectural masterpieces include the Vittala Temple with its iconic stone chariot, the Virupaksha Temple, the Queen's Bath, and the Elephant Stables.",
    additionalImages: [
      "https://karnatakatourism.org/wp-content/uploads/2020/06/hampi-stone-chariot.jpg",
      "https://karnatakatourism.org/wp-content/uploads/2020/06/hampi-ruins.jpg",
      "https://karnatakatourism.org/wp-content/uploads/2020/06/virupaksha-temple-hampi.jpg"
    ]
  },
  {
    id: 2,
    name: "Mysore Palace",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/05/mysore-palace-1.jpg",
    fallbackImage: "https://www.karnatakatourism.org/wp-content/uploads/2020/06/mysore-palace-night.jpg", 
    description: "The magnificent royal residence of the Wodeyar dynasty, illuminated by thousands of lights.",
    rating: 4.8,
    detailedInfo: "Mysore Palace, also known as Amba Vilas Palace, is the official residence of the Wodeyar dynasty who ruled Mysore from 1399 to 1950. The current structure was built in 1912 after the old palace was destroyed in a fire. The palace is a harmonious blend of Hindu, Muslim, Rajput, and Gothic architectural styles. Its Sunday evening illumination with nearly 100,000 lights is a spectacular sight. Inside, visitors can marvel at the ornate ceilings, stained glass windows, intricately carved doors, and the Golden Throne displayed during Dasara celebrations.",
    additionalImages: [
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/mysore-palace-night.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/mysore-palace-interior.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/mysore-palace-gate.jpg"
    ]
  },
  {
    id: 3,
    name: "Jog Falls",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/05/jog-falls-1.jpg",
    fallbackImage: "https://www.karnatakatourism.org/wp-content/uploads/2020/06/jog-falls-top-view.jpg",
    description: "One of India's tallest waterfalls as it cascades down in four distinct flows.",
    rating: 4.7,
    detailedInfo: "Jog Falls is the second-highest plunge waterfall in India, created by the Sharavathi River falling from a height of 829 feet (253 meters). The falls are segmented into four distinct cascades known locally as Raja (King), Rani (Queen), Roarer, and Rocket. The best time to visit is during the monsoon season (June to September) when the falls are at their magnificent best. During this time, the water gushes down with tremendous force creating a spectacular sight. A 1,400-step path leads to the bottom of the falls, offering breathtaking views.",
    additionalImages: [
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/jog-falls-top-view.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/jog-falls-rainbow.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/jog-falls-monsoon.jpg"
    ]
  },
  {
    id: 4,
    name: "Badami Cave Temples",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/05/badami-1.jpg", 
    fallbackImage: "https://www.karnatakatourism.org/wp-content/uploads/2020/06/badami-cave-2.jpg",
    description: "Ancient rock-cut cave temples dating back to the 6th century with stunning sandstone architecture.",
    rating: 4.8,
    detailedInfo: "Badami Cave Temples, carved out of sandstone hills in the 6th and 7th centuries, are a remarkable example of Indian rock-cut architecture. There are four main caves dedicated to different deities - Shiva, Vishnu, Jain Tirthankaras, and a combination of these faiths. The caves feature intricate carvings depicting various Hindu mythological themes and divine figures. The most impressive is Cave 3, dedicated to Vishnu, which contains a stunning 18-armed carving of the dancing Nataraja. The site also offers beautiful views of Agastya Lake and the surrounding ancient fortifications.",
    additionalImages: [
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/badami-cave-2.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/badami-cave-interior.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/badami-lake-view.jpg"
    ]
  },
  {
    id: 5,
    name: "Coorg",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/05/coorg-1.jpg",
    fallbackImage: "https://www.karnatakatourism.org/wp-content/uploads/2020/06/coorg-coffee.jpg",
    description: "Misty hill station known for coffee plantations, lush forests, and vibrant local culture.",
    rating: 4.7,
    detailedInfo: "Coorg, also known as Kodagu, is a picturesque hill station nestled in the Western Ghats of Karnataka. Famous for its coffee plantations, this region is often called the 'Scotland of India' for its breathtaking landscapes and cool climate. The Kodavas, the local community, have a distinct culture with unique traditions and cuisine. Visitors can explore the Abbey Falls, Dubare Elephant Camp, and the Namdroling Monastery (Golden Temple). Trekking opportunities abound at Tadiandamol Peak and Brahmagiri Hills, while the Nisargadhama Island and Raja's Seat offer serene natural beauty.",
    additionalImages: [
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/coorg-coffee.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/coorg-abbey-falls.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/coorg-monastery.jpg"
    ]
  },
  {
    id: 6,
    name: "Gokarna Beach",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/05/gokarna-1.jpg",
    fallbackImage: "https://www.karnatakatourism.org/wp-content/uploads/2020/06/gokarna-om-beach.jpg",
    description: "Pristine beaches and spiritual ambiance with ancient temples make it a unique destination.",
    rating: 4.6,
    detailedInfo: "Gokarna is a small temple town on the western coast of Karnataka, known for its pristine beaches and religious significance. The town is home to several sacred sites including the Mahabaleshwar Temple, which houses one of the ancient Atma Lingas. The beaches of Gokarna, including Om Beach (shaped like the Om symbol), Half Moon Beach, Paradise Beach, and Kudle Beach, offer a more serene alternative to the busy beaches of Goa. Gokarna has gained popularity among both pilgrims and tourists seeking a blend of spirituality and coastal relaxation, with yoga retreats, water sports, and beachside accommodations.",
    additionalImages: [
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/gokarna-om-beach.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/gokarna-temple.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2020/06/gokarna-paradise-beach.jpg"
    ]
  },
  {
    id: 7,
    name: "Bangalore",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/06/bangalore-1.jpg",
    fallbackImage: "https://www.karnatakatourism.org/wp-content/uploads/2021/03/bangalore-palace.jpg",
    description: "The Silicon Valley of India known for its tech industry, gardens, and pleasant climate.",
    rating: 4.5,
    detailedInfo: "Bangalore, officially known as Bengaluru, is the capital city of Karnataka and is known as the 'Silicon Valley of India' for its role as the nation's leading IT exporter. The city enjoys a pleasant climate throughout the year and is famous for its beautiful parks and gardens, particularly Lalbagh and Cubbon Park. Historical attractions include the Bangalore Palace (inspired by England's Windsor Castle) and the Bull Temple (Nandi Temple). Modern landmarks include Vidhana Soudha (the state legislature building), UB City, and various science museums. The city is also known for its vibrant food scene, microbreweries, and cultural festivals.",
    additionalImages: [
      "https://www.karnatakatourism.org/wp-content/uploads/2021/03/bangalore-palace.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2021/03/bangalore-lalbagh.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2021/03/bangalore-vidhana-soudha.jpg"
    ]
  },
  {
    id: 8,
    name: "Murudeshwar",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/06/murudeshwar-1.jpg",
    fallbackImage: "https://www.karnatakatourism.org/wp-content/uploads/2021/03/murudeshwar-statue.jpg",
    description: "Home to the second tallest Shiva statue in the world and stunning coastal views.",
    rating: 4.7,
    detailedInfo: "Murudeshwar is a coastal town famous for housing the world's second-tallest Shiva statue (123 feet) overlooking the Arabian Sea. The statue is situated near the Murudeshwar Temple, which is dedicated to Lord Shiva. The temple complex features a 20-story gopuram (tower) that offers panoramic views of the coastline. According to Hindu mythology, this is where Lord Shiva gave Ravana the Atma Linga and parts of it fell when Ravana placed it on the ground. Besides its religious significance, Murudeshwar is known for its beautiful beaches and water sports including snorkeling, jet skiing, and banana boat rides. The nearby Netrani Island is a popular diving spot known for its coral reefs.",
    additionalImages: [
      "https://www.karnatakatourism.org/wp-content/uploads/2021/03/murudeshwar-statue.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2021/03/murudeshwar-temple.jpg",
      "https://www.karnatakatourism.org/wp-content/uploads/2021/03/murudeshwar-beach.jpg"
    ]
  }
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

const FeaturedPlaces = () => {
  const [imageErrors, setImageErrors] = useState<{[key: number]: boolean}>({});
  const [visiblePlaces, setVisiblePlaces] = useState(4);
  const [selectedPlace, setSelectedPlace] = useState<typeof featuredPlaces[0] | null>(null);

  const handleImageError = (id: number) => {
    setImageErrors(prev => ({...prev, [id]: true}));
  };

  const handleViewMore = () => {
    setVisiblePlaces(prev => 
      prev === 4 ? featuredPlaces.length : 4
    );
  };

  // Preload images
  useEffect(() => {
    featuredPlaces.forEach(place => {
      const img = new Image();
      img.src = place.image;
      const fallbackImg = new Image();
      fallbackImg.src = place.fallbackImage;
      
      // Preload additional images
      place.additionalImages?.forEach(imgSrc => {
        const addImg = new Image();
        addImg.src = imgSrc;
      });
    });
  }, []);

  return (
    <div className="py-16 px-4 bg-gradient-to-br from-purple-100 via-blue-50 to-indigo-100">
      <div className="flex justify-between items-center mb-10">
        <motion.h2 
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="text-3xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent"
        >
          Discover Karnataka's Treasures
        </motion.h2>
        <Link to="/explore">
          <Button variant="ghost" className="text-blue-600 hover:text-blue-700 hover:bg-blue-100 group">
            View all
            <ArrowRight size={16} className="ml-1 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </div>
      
      <motion.div 
        variants={container}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
      >
        {featuredPlaces.slice(0, visiblePlaces).map((place) => (
          <motion.div key={place.id} variants={item}>
            <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 bg-white border border-indigo-100 rounded-xl hover:-translate-y-2 h-full">
              <div className="relative">
                <AspectRatio ratio={4/3}>
                  <img 
                    src={imageErrors[place.id] ? place.fallbackImage : place.image}
                    alt={place.name} 
                    className="w-full h-full object-cover"
                    onError={() => handleImageError(place.id)}
                  />
                </AspectRatio>
                <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 text-xs font-medium flex items-center shadow-md">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-amber-500 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                  {place.rating}
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-3 text-gray-800">{place.name}</h3>
                <p className="text-gray-600 mb-5 line-clamp-3">{place.description}</p>
                <Button 
                  onClick={() => setSelectedPlace(place)}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white transition-colors shadow hover:shadow-md"
                >
                  Explore
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {featuredPlaces.length > 4 && (
        <div className="flex justify-center mt-10">
          <Button 
            onClick={handleViewMore} 
            variant="outline"
            className="border-blue-600 text-blue-600 hover:bg-blue-50"
          >
            {visiblePlaces === 4 ? "View More Places" : "Show Less"}
          </Button>
        </div>
      )}

      {/* Detail Dialog */}
      <Dialog open={!!selectedPlace} onOpenChange={(open) => !open && setSelectedPlace(null)}>
        <DialogContent className="max-w-3xl h-[80vh] overflow-y-auto">
          {selectedPlace && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold text-blue-700">{selectedPlace.name}</DialogTitle>
                <DialogDescription className="flex items-center text-sm font-medium">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-amber-500 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                  <span className="mr-2">{selectedPlace.rating}/5 Rating</span>
                </DialogDescription>
              </DialogHeader>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
                <div>
                  <div className="rounded-lg overflow-hidden shadow-md">
                    <img 
                      src={imageErrors[selectedPlace.id] ? selectedPlace.fallbackImage : selectedPlace.image} 
                      alt={selectedPlace.name}
                      className="w-full h-64 object-cover"
                      onError={() => handleImageError(selectedPlace.id)}
                    />
                  </div>
                  <p className="mt-6 text-gray-700 leading-relaxed">{selectedPlace.detailedInfo}</p>

                  <div className="mt-4">
                    <Link to={`/explore?destination=${encodeURIComponent(selectedPlace.name)}`}>
                      <Button className="mt-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                        Plan Your Visit <Info size={16} className="ml-2" />
                      </Button>
                    </Link>
                  </div>
                </div>

                <div className="space-y-4">
                  {selectedPlace.additionalImages?.map((img, idx) => (
                    <div key={idx} className="rounded-lg overflow-hidden shadow-md">
                      <img 
                        src={img} 
                        alt={`${selectedPlace.name} - view ${idx+1}`}
                        className="w-full h-40 object-cover hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FeaturedPlaces;
