
import { Link } from "react-router-dom";
import { Search, Map, Users, CalendarDays, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Hero = () => {
  return (
    <div className="relative bg-gradient-to-r from-triptrove-blue to-blue-900 text-white overflow-hidden py-16 md:py-24">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="h-full w-full" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
          <pattern id="dots" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1" fill="white" />
          </pattern>
          <rect x="0" y="0" width="100%" height="100%" fill="url(#dots)" />
        </svg>
      </div>
      
      {/* Content */}
      <div className="triptrove-container relative z-10">
        <div className="grid gap-8 md:grid-cols-2 items-center">
          {/* Hero Text */}
          <div className="text-center md:text-left space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight animate-fade-in">
              Discover the Beauty of Karnataka
            </h1>
            <p className="text-lg md:text-xl opacity-90 max-w-xl animate-slide-up">
              Connect with fellow travelers, plan your perfect journey, and explore the diverse landscapes and cultures of Karnataka.
            </p>
            
            {/* Search */}
            <div className="flex flex-col sm:flex-row gap-2 max-w-xl">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search for places in Karnataka..."
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:border-white w-full h-12"
                />
              </div>
              <Button className="h-12 px-8 bg-triptrove-gold hover:bg-opacity-90 text-triptrove-blue font-medium">
                Search
              </Button>
            </div>
            
            {/* Feature Badges */}
            <div className="flex flex-wrap justify-center md:justify-start gap-3 pt-2">
              <div className="flex items-center bg-white/10 rounded-full px-4 py-2 backdrop-blur-sm">
                <Map className="h-4 w-4 mr-2" />
                <span className="text-sm">Interactive Routes</span>
              </div>
              <div className="flex items-center bg-white/10 rounded-full px-4 py-2 backdrop-blur-sm">
                <Users className="h-4 w-4 mr-2" />
                <span className="text-sm">Community</span>
              </div>
              <div className="flex items-center bg-white/10 rounded-full px-4 py-2 backdrop-blur-sm">
                <CalendarDays className="h-4 w-4 mr-2" />
                <span className="text-sm">Events</span>
              </div>
              <div className="flex items-center bg-white/10 rounded-full px-4 py-2 backdrop-blur-sm">
                <TrendingUp className="h-4 w-4 mr-2" />
                <span className="text-sm">Travel Insights</span>
              </div>
            </div>
          </div>
          
          {/* Featured Image */}
          <div className="relative h-full flex justify-center">
            <div className="w-full max-w-lg aspect-[4/3] bg-gradient-to-tr from-triptrove-gold/20 to-triptrove-terracotta/20 rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1590766940522-a2539e14df48?auto=format&fit=crop&w=800"
                alt="Karnataka Tourism"
                className="w-full h-full object-cover mix-blend-luminosity opacity-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-triptrove-blue/50 to-transparent"></div>
              
              {/* Stats overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-6 flex justify-between">
                <div className="text-center">
                  <div className="text-2xl font-bold">30+</div>
                  <div className="text-xs">Top Destinations</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">1000+</div>
                  <div className="text-xs">Community Members</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">5000+</div>
                  <div className="text-xs">Routes Planned</div>
                </div>
              </div>
            </div>
            
            {/* Decorative Elements */}
            <div className="absolute -top-4 -right-4 bg-triptrove-gold h-16 w-16 rounded-full opacity-80 blur-xl"></div>
            <div className="absolute -bottom-6 -left-6 bg-triptrove-terracotta h-20 w-20 rounded-full opacity-50 blur-xl"></div>
          </div>
        </div>
        
        {/* Call to Action Buttons */}
        <div className="mt-12 flex flex-wrap justify-center md:justify-start gap-4">
          <Link to="/explore">
            <Button className="triptrove-btn-secondary text-lg px-8 py-6">
              Start Exploring
            </Button>
          </Link>
          <Link to="/community">
            <Button variant="outline" className="text-lg px-8 py-6 border-white/30 hover:bg-white/10">
              Join Community
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Hero;
