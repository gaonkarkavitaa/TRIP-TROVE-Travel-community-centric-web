
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const CommunityHighlights = () => {
  const recentDiscussions = [
    {
      id: 1,
      title: "Best time to visit Coorg?",
      user: {
        name: "Priya Sharma",
        avatar: "https://randomuser.me/api/portraits/women/45.jpg",
      },
      replies: 24,
      category: "Travel Planning"
    },
    {
      id: 2,
      title: "Transport options from Bangalore to Mysore",
      user: {
        name: "Rahul Patel",
        avatar: "https://randomuser.me/api/portraits/men/22.jpg",
      },
      replies: 19,
      category: "Transportation"
    },
    {
      id: 3,
      title: "Hidden gems near Hampi that tourists miss",
      user: {
        name: "Ananya Desai",
        avatar: "https://randomuser.me/api/portraits/women/32.jpg",
      },
      replies: 31,
      category: "Local Secrets"
    }
  ];
  
  const upcomingEvents = [
    {
      id: 1,
      title: "Bangalore Photography Walk",
      date: "April 15, 2025",
      attendees: 42,
      location: "Cubbon Park, Bangalore",
    },
    {
      id: 2,
      title: "Coastal Karnataka Food Festival",
      date: "April 22, 2025",
      attendees: 76,
      location: "Mangalore Beach",
    }
  ];
  
  const recentBlogs = [
    {
      id: 1,
      title: "My week-long adventure in Western Ghats",
      excerpt: "Exploring the verdant valleys and misty mountains of Western Ghats...",
      user: {
        name: "Vikram Singh",
        avatar: "https://randomuser.me/api/portraits/men/35.jpg",
      },
      likes: 124,
      category: "Adventure"
    },
    {
      id: 2,
      title: "Historical tour through Mysore and Srirangapatna",
      excerpt: "A journey through time exploring Karnataka's rich historical heritage...",
      user: {
        name: "Meera Krishnan",
        avatar: "https://randomuser.me/api/portraits/women/68.jpg",
      },
      likes: 98,
      category: "History"
    }
  ];

  return (
    <div className="py-12">
      <h2 className="text-3xl font-bold text-triptrove-blue mb-8">Community Highlights</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Forum Discussions */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex justify-between items-center">
              <span>Recent Discussions</span>
              <Link to="/forum">
                <Button variant="ghost" size="sm" className="text-xs">View All</Button>
              </Link>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentDiscussions.map((discussion) => (
                <div key={discussion.id} className="p-3 rounded-lg border">
                  <div className="flex justify-between items-start mb-2">
                    <Link to={`/forum/discussion/${discussion.id}`} className="text-md font-medium hover:text-triptrove-blue transition-colors">
                      {discussion.title}
                    </Link>
                    <Badge variant="outline" className="text-xs">{discussion.category}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={discussion.user.avatar} />
                        <AvatarFallback>{discussion.user.name[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">{discussion.user.name}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">{discussion.replies} replies</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Upcoming Events */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex justify-between items-center">
              <span>Upcoming Events</span>
              <Link to="/events">
                <Button variant="ghost" size="sm" className="text-xs">View All</Button>
              </Link>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingEvents.map((event) => (
                <div key={event.id} className="p-3 rounded-lg border">
                  <Link to={`/events/${event.id}`} className="text-md font-medium hover:text-triptrove-blue transition-colors">
                    {event.title}
                  </Link>
                  <div className="mt-2 space-y-1">
                    <div className="flex items-center text-muted-foreground">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                      <span className="text-xs">{event.date}</span>
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                      <span className="text-xs">{event.location}</span>
                    </div>
                    <div className="flex items-center text-muted-foreground">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                      <span className="text-xs">{event.attendees} attending</span>
                    </div>
                  </div>
                </div>
              ))}
              <Link to="/events/create">
                <Button variant="outline" className="w-full text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Create New Event
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        {/* Recent Blogs */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex justify-between items-center">
              <span>Latest Blogs</span>
              <Link to="/blogs">
                <Button variant="ghost" size="sm" className="text-xs">View All</Button>
              </Link>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentBlogs.map((blog) => (
                <div key={blog.id} className="p-3 rounded-lg border">
                  <div className="flex justify-between items-start mb-1">
                    <Link to={`/blogs/${blog.id}`} className="text-md font-medium hover:text-triptrove-blue transition-colors">
                      {blog.title}
                    </Link>
                    <Badge variant="secondary" className="text-xs">{blog.category}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                    {blog.excerpt}
                  </p>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={blog.user.avatar} />
                        <AvatarFallback>{blog.user.name[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">{blog.user.name}</span>
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                      </svg>
                      {blog.likes}
                    </div>
                  </div>
                </div>
              ))}
              <Link to="/blogs/create">
                <Button variant="outline" className="w-full text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                  Write a Blog
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CommunityHighlights;
