
import { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, X, MapPin, User, MessageSquare, BookOpen, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="triptrove-container flex justify-between items-center py-4">
        <Link to="/" className="flex items-center space-x-2">
          <MapPin className="h-8 w-8 text-triptrove-blue" />
          <span className="text-2xl font-bold text-triptrove-blue">TripTrove</span>
        </Link>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <NavLinks />
          <div className="flex items-center space-x-4">
            <Button variant="ghost" className="rounded-full">
              <Avatar>
                <AvatarFallback className="bg-triptrove-blue text-white">
                  U
                </AvatarFallback>
              </Avatar>
            </Button>
            <Button className="triptrove-btn-primary">Sign In</Button>
          </div>
        </div>
        
        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <Button variant="ghost" onClick={toggleMenu} className="p-2">
            {isMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </Button>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white py-4 px-6 animate-fade-in">
          <div className="flex flex-col space-y-4">
            <MobileNavLinks toggleMenu={toggleMenu} />
            <div className="pt-4 border-t border-gray-200">
              <Button className="triptrove-btn-primary w-full">Sign In</Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

const NavLinks = () => {
  return (
    <>
      <Link to="/explore" className="text-gray-700 hover:text-triptrove-blue transition-colors font-medium">
        Explore
      </Link>
      <Link to="/forum" className="text-gray-700 hover:text-triptrove-blue transition-colors font-medium">
        Forum
      </Link>
      <Link to="/blogs" className="text-gray-700 hover:text-triptrove-blue transition-colors font-medium">
        Blogs
      </Link>
      <Link to="/events" className="text-gray-700 hover:text-triptrove-blue transition-colors font-medium">
        Events
      </Link>
    </>
  );
};

const MobileNavLinks = ({ toggleMenu }: { toggleMenu: () => void }) => {
  const links = [
    { to: "/explore", label: "Explore", icon: <MapPin className="h-5 w-5 mr-2" /> },
    { to: "/forum", label: "Forum", icon: <MessageSquare className="h-5 w-5 mr-2" /> },
    { to: "/blogs", label: "Blogs", icon: <BookOpen className="h-5 w-5 mr-2" /> },
    { to: "/events", label: "Events", icon: <Calendar className="h-5 w-5 mr-2" /> },
    { to: "/profile", label: "Profile", icon: <User className="h-5 w-5 mr-2" /> },
  ];
  
  return (
    <>
      {links.map((link) => (
        <Link 
          key={link.to} 
          to={link.to} 
          className="flex items-center py-2 text-gray-700 hover:text-triptrove-blue transition-colors" 
          onClick={toggleMenu}
        >
          {link.icon}
          {link.label}
        </Link>
      ))}
    </>
  );
};

export default Navbar;
