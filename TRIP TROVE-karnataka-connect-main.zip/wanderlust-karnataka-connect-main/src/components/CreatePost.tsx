
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Camera, MapPin, Upload } from "lucide-react";
import { useNavigate } from "react-router-dom";

const CreatePost = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [location, setLocation] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImage(file);
    
    // Create a preview
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "You must be logged in to create a post",
        description: "Please sign in or create an account",
        variant: "destructive"
      });
      navigate("/auth");
      return;
    }
    
    if (!title || !content) {
      toast({
        title: "Missing information",
        description: "Please provide a title and content for your post",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      let cover_image_url = null;
      
      // Upload image if selected
      if (image) {
        const file_ext = image.name.split('.').pop();
        const file_name = `${Math.random().toString(36).substring(2, 15)}.${file_ext}`;
        const file_path = `blog-images/${user.id}/${file_name}`;
        
        const { error: uploadError, data } = await supabase.storage
          .from('trip-trove-uploads')
          .upload(file_path, image);
        
        if (uploadError) throw uploadError;
        
        cover_image_url = `https://mokddjxocwwypgoobuyp.supabase.co/storage/v1/object/public/trip-trove-uploads/${file_path}`;
      }
      
      // Save blog post
      const { error } = await supabase.from('blogs').insert({
        user_id: user.id,
        title,
        content,
        location,
        cover_image: cover_image_url
      });
      
      if (error) throw error;
      
      toast({
        title: "Post created successfully",
        description: "Your experience has been shared with the community",
      });
      
      // Reset form or redirect
      navigate("/community");
      
    } catch (error) {
      console.error("Error creating post:", error);
      toast({
        title: "Failed to create post",
        description: error.message || "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-triptrove-blue mb-6">Share Your Experience</h1>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
            Title
          </label>
          <Input
            id="title"
            placeholder="Give your experience a catchy title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full"
          />
        </div>
        
        <div>
          <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
            Location
          </label>
          <div className="flex items-center">
            <MapPin className="w-5 h-5 text-gray-400 mr-2" />
            <Input
              id="location"
              placeholder="Where did you visit?"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full"
            />
          </div>
        </div>
        
        <div>
          <label htmlFor="content" className="block text-sm font-medium text-gray-700 mb-1">
            Your Experience
          </label>
          <Textarea
            id="content"
            placeholder="Share your experience and recommendations..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={8}
            className="w-full"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Upload Cover Image
          </label>
          <div className="flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg p-6 cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => document.getElementById('image-upload')?.click()}>
            <input
              type="file"
              id="image-upload"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
            />
            {imagePreview ? (
              <img src={imagePreview} alt="Preview" className="max-h-48 rounded" />
            ) : (
              <div className="text-center">
                <Camera className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-2 text-sm text-gray-500">Click to upload an image</p>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex justify-end space-x-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate(-1)}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            className="triptrove-btn-primary"
            disabled={isSubmitting}
          >
            {isSubmitting ? "Publishing..." : "Publish Post"}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default CreatePost;
