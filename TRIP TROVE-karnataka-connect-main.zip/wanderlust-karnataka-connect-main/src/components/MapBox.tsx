import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

declare global {
  interface Window {
    MapmyIndia: {
      Map: new (container: HTMLElement, options: any) => any;
      Marker: new (options: any) => any;
      LatLngBounds: new () => any;
      icon: (options: any) => any;
    };
    L: any;
  }
}

interface MapBoxProps {
  selectedLocations?: string[];
  onLocationSelect?: (location: string) => void;
}

const MapBox = ({ selectedLocations = [], onLocationSelect }: MapBoxProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const mapRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const scriptLoadedRef = useRef<boolean>(false);

  const defaultCenter = { lat: 14.5, lng: 76.5 };
  
  const mapApiKey = "372586837566fa6c155dc7472ba83f33";
  
  const touristSpots = {
    "Hampi": { lat: 15.3350, lng: 76.4600 },
    "Mysore Palace": { lat: 12.3052, lng: 76.6552 },
    "Jog Falls": { lat: 14.2545, lng: 74.7928 },
    "Badami Cave Temples": { lat: 15.9166, lng: 75.6818 },
    "Gokarna Beach": { lat: 14.5440, lng: 74.3185 },
    "Coorg": { lat: 12.4244, lng: 75.7382 },
    "Bangalore": { lat: 12.9716, lng: 77.5946 },
    "Udupi": { lat: 13.3409, lng: 74.7421 },
    "Murudeshwar": { lat: 14.0994, lng: 74.4848 },
    "Chikmagalur": { lat: 13.3161, lng: 75.7720 }
  };

  useEffect(() => {
    const loadMapScript = () => {
      if (scriptLoadedRef.current) return;
      
      const script = document.createElement("script");
      script.src = `https://apis.mapmyindia.com/advancedmaps/v1/${mapApiKey}/map_load?v=1.5`;
      script.async = true;
      script.defer = true;
      
      script.onload = () => {
        scriptLoadedRef.current = true;
        console.log("MapMyIndia script loaded successfully");
        setTimeout(initializeMap, 500);
      };
      
      script.onerror = () => {
        toast.error("Failed to load MapMyIndia API. Please try again later.");
        console.error("MapMyIndia script failed to load");
      };
      
      document.body.appendChild(script);
    };

    if (!window.MapmyIndia && !scriptLoadedRef.current && !document.querySelector('script[src*="mapmyindia"]')) {
      loadMapScript();
    } else if (window.MapmyIndia && !mapLoaded) {
      initializeMap();
    }

    return () => {
      if (mapRef.current) {
        mapRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (mapLoaded && mapRef.current) {
      updateMarkers();
    }
  }, [selectedLocations, mapLoaded]);

  const initializeMap = () => {
    if (!mapContainer.current || mapRef.current) return;
    
    if (!window.MapmyIndia) {
      console.error("MapmyIndia library not loaded yet");
      return;
    }
    
    try {
      console.log("Initializing MapMyIndia map");
      console.log("Map container exists:", !!mapContainer.current);
      
      const map = new window.MapmyIndia.Map(mapContainer.current, {
        center: [defaultCenter.lat, defaultCenter.lng],
        zoom: 7,
        zoomControl: true,
        hybrid: true
      });
      
      mapRef.current = map;
      
      map.addEventListener('click', function(e: any) {
        const lat = e.latlng.lat;
        const lng = e.latlng.lng;
        console.log(`Map clicked at: ${lat}, ${lng}`);
        
        const nearest = findNearestTouristSpot(lat, lng);
        
        if (nearest && onLocationSelect) {
          toast.info(`Selected location: ${nearest}`);
          onLocationSelect(nearest);
        }
      });
      
      if (window.L) {
        Object.entries(touristSpots).forEach(([name, coords]) => {
          const marker = window.L.marker([coords.lat, coords.lng], {
            title: name
          }).addTo(map);
          
          marker.bindPopup(name);
          
          marker.on('click', () => {
            if (onLocationSelect) {
              onLocationSelect(name);
              toast.info(`Selected: ${name}`);
            }
          });
        });
      } else {
        console.error("Leaflet (L) is not available");
        toast.error("Map functionality is limited. Please try refreshing the page.");
      }
      
      setMapLoaded(true);
      console.log("Map initialized successfully");
    } catch (error) {
      console.error("Error initializing map:", error);
      toast.error("Failed to initialize map. Please try again later.");
    }
  };

  const updateMarkers = () => {
    if (!mapRef.current || !window.L) return;
    
    markersRef.current.forEach(marker => {
      if (marker && marker.remove) {
        marker.remove();
      }
    });
    markersRef.current = [];
    
    selectedLocations.forEach((location, index) => {
      const coords = touristSpots[location as keyof typeof touristSpots];
      if (coords) {
        try {
          const icon = window.L.icon({
            iconUrl: `https://apis.mapmyindia.com/map_v3/1.png`,
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
          });
          
          const marker = window.L.marker([coords.lat, coords.lng], {
            icon: icon,
            title: `${index + 1}. ${location}`,
            draggable: false
          }).addTo(mapRef.current);
          
          marker.bindPopup(`<b>${index + 1}. ${location}</b>`);
          markersRef.current.push(marker);
        } catch (error) {
          console.error(`Error adding marker for ${location}:`, error);
        }
      }
    });
    
    if (selectedLocations.length > 0 && window.L) {
      try {
        const bounds = new window.L.LatLngBounds();
        let validBounds = false;
        
        selectedLocations.forEach(location => {
          const coords = touristSpots[location as keyof typeof touristSpots];
          if (coords) {
            bounds.extend([coords.lat, coords.lng]);
            validBounds = true;
          }
        });
        
        if (validBounds && !bounds.isEmpty()) {
          mapRef.current.fitBounds(bounds, { padding: [50, 50] });
        }
      } catch (error) {
        console.error("Error fitting bounds:", error);
      }
    }
  };
  
  const findNearestTouristSpot = (lat: number, lng: number) => {
    let nearest = null;
    let minDistance = Infinity;
    
    Object.entries(touristSpots).forEach(([name, coords]) => {
      const distance = Math.sqrt(
        Math.pow(coords.lat - lat, 2) + 
        Math.pow(coords.lng - lng, 2)
      );
      
      if (distance < minDistance) {
        minDistance = distance;
        nearest = name;
      }
    });
    
    return minDistance < 0.5 ? nearest : null;
  };

  return (
    <div className="relative w-full">
      <div 
        ref={mapContainer} 
        id="map-container"
        className="h-[400px] w-full rounded-md border border-gray-300 bg-gray-100"
      >
        {!mapLoaded && (
          <div className="flex h-full w-full items-center justify-center">
            <div className="text-gray-500">Loading map...</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MapBox;
