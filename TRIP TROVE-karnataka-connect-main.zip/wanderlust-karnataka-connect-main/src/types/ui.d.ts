
declare module "@/components/ui/calendar" {
  import { DayPicker } from "react-day-picker";
  
  export type CalendarProps = React.ComponentProps<typeof DayPicker>;
  
  export function Calendar({
    className,
    classNames,
    showOutsideDays,
    ...props
  }: CalendarProps): JSX.Element;
}

declare module "@/components/ui/date-picker" {
  interface DatePickerProps {
    date?: Date;
    onSelect: (date: Date | undefined) => void;
  }
  
  export function DatePicker({
    date,
    onSelect,
  }: DatePickerProps): JSX.Element;
}
