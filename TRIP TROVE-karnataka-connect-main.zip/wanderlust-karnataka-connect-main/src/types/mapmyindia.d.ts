
// Type definitions for MapMyIndia map API
interface MapmyIndiaMap {
  Map: new (container: HTMLElement, options: any) => any;
  Marker: new (options: any) => any;
  LatLngBounds: new () => any;
  icon: (options: any) => any;
}

declare global {
  interface Window {
    MapmyIndia: MapmyIndiaMap;
    L: any;
  }
}

export {};
