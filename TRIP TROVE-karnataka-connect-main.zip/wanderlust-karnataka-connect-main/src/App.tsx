
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import "./App.css";
import { AuthProvider, useAuth } from "./hooks/useAuth";
import Index from "./pages/Index";
import SchoolTripPlanner from "./pages/SchoolTripPlanner";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";
import CreatePostPage from "./pages/CreatePostPage";
import CreateEventPage from "./pages/CreateEventPage";
import Community from "./pages/Community";
import Dashboard from "./pages/Dashboard";
import UserDashboard from "./pages/UserDashboard";
import ContentDetails from "./pages/ContentDetails";
import Explore from "./pages/Explore";

// Protected route component that redirects to auth if not logged in
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();
  
  // Show nothing while checking authentication status
  if (loading) return null;
  
  // Redirect to auth page if not logged in
  if (!user) {
    return <Navigate to="/auth" replace />;
  }
  
  return <>{children}</>;
};

function AppRoutes() {
  const { user } = useAuth();
  
  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/auth" element={user ? <Navigate to="/user-dashboard" /> : <Auth />} />
      <Route path="/user-dashboard" element={<ProtectedRoute><UserDashboard /></ProtectedRoute>} />
      <Route path="/school-trip-planner" element={<ProtectedRoute><SchoolTripPlanner /></ProtectedRoute>} />
      <Route path="/create-post" element={<ProtectedRoute><CreatePostPage /></ProtectedRoute>} />
      <Route path="/create-event" element={<ProtectedRoute><CreateEventPage /></ProtectedRoute>} />
      <Route path="/community" element={<ProtectedRoute><Community /></ProtectedRoute>} />
      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/explore" element={<ProtectedRoute><Explore /></ProtectedRoute>} />
      <Route path="/:contentType/:id" element={<ProtectedRoute><ContentDetails /></ProtectedRoute>} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

function App() {
  return (
    <Router>
      <AuthProvider>
        <AppRoutes />
        <Toaster position="top-right" />
      </AuthProvider>
    </Router>
  );
}

export default App;
