
// This file contains mock data for Karnataka tourist spots
// In a real application, this would come from an API

export const karnatakaTouristSpots = [
  "Mysore Palace",
  "Hampi",
  "Jog Falls",
  "Gokarna Beach",
  "Coorg",
  "Bangalore Palace",
  "Nandi Hills",
  "Badami Caves",
  "Bandipur National Park",
  "Murudeshwara",
  "Udupi",
  "Belur",
  "Halebidu",
  "Shivanasamudra Falls",
  "Aihole",
  "Pattadakal",
  "Kudremukh",
  "Kabini River",
  "Chikmagalur",
  "Ranganathittu Bird Sanctuary",
  "Vidhana Soudha",
  "Cubbon Park",
  "Lalbagh Botanical Garden",
  "Srirangapatna",
];

export const popularRoutes = [
  {
    id: 1,
    name: "Heritage Tour",
    places: ["Mysore Palace", "Srirangapatna", "Hampi", "Badami Caves"],
    days: 5,
    distance: 650,
    category: "History & Culture"
  },
  {
    id: 2,
    name: "Western Ghats Adventure",
    places: ["Coorg", "Chikmagalur", "Jog Falls", "Kudremukh"],
    days: 4,
    distance: 480,
    category: "Nature & Adventure"
  },
  {
    id: 3,
    name: "Coastal Karnataka",
    places: ["Gokarna Beach", "Murudeshwara", "Udupi", "Mangalore"],
    days: 3,
    distance: 320,
    category: "Beaches & Temples"
  },
  {
    id: 4,
    name: "Bangalore Weekend",
    places: ["Nandi Hills", "Bangalore Palace", "Lalbagh", "Cubbon Park"],
    days: 2,
    distance: 120,
    category: "Weekend Getaway"
  }
];

export const transportOptions = [
  {
    id: "car",
    name: "Car",
    icon: "🚗",
    advantages: ["Flexibility", "Door-to-door convenience", "Privacy"],
    disadvantages: ["Traffic", "Parking issues", "Driver fatigue for long routes"]
  },
  {
    id: "bus",
    name: "Bus",
    icon: "🚌",
    advantages: ["Economical", "Extensive network", "No parking hassles"],
    disadvantages: ["Fixed schedules", "Comfort varies", "Limited luggage space"]
  },
  {
    id: "train",
    name: "Train",
    icon: "🚆",
    advantages: ["Scenic routes", "Comfortable for long journeys", "No traffic"],
    disadvantages: ["Limited station locations", "Advance booking required", "Delays possible"]
  },
  {
    id: "flight",
    name: "Flight",
    icon: "✈️",
    advantages: ["Fast", "Best for long distances", "Time-saving"],
    disadvantages: ["Expensive", "Limited to major cities", "Airport procedures"]
  }
];

export const weatherInfo = [
  { 
    season: "Summer (March-May)",
    temperature: "24°C - 36°C",
    description: "Hot and dry in most regions. Hill stations like Coorg remain cooler.",
    recommendation: "Visit hill stations, waterfalls, or coastal areas. Early morning or evening activities recommended."
  },
  { 
    season: "Monsoon (June-September)",
    temperature: "20°C - 28°C",
    description: "Heavy rainfall, especially in coastal and Western Ghats regions. Lush green landscapes.",
    recommendation: "Ideal for nature photography, tea/coffee plantations visits. Some attractions may have limited access."
  },
  { 
    season: "Post-Monsoon (October-November)",
    temperature: "18°C - 30°C",
    description: "Moderate temperatures with occasional showers. Fresh landscapes after monsoon.",
    recommendation: "Great time for most tourist activities with fewer crowds. Perfect for outdoor explorations."
  },
  { 
    season: "Winter (December-February)",
    temperature: "14°C - 28°C",
    description: "Pleasant daytime temperatures. Cooler nights, especially in hill stations.",
    recommendation: "Peak tourist season with excellent weather for sightseeing and outdoor activities."
  }
];
