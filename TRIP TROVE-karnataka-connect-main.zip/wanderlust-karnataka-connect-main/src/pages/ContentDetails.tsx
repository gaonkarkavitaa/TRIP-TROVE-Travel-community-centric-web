import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import NavbarUpdated from "@/components/NavbarUpdated";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, ChevronLeft, User, Clock, Map, Calendar as CalendarIcon, Info, Map as MapIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import MapBox from "@/components/MapBox";

const ContentDetails = () => {
  const { contentType, id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [content, setContent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [author, setAuthor] = useState<any>(null);

  useEffect(() => {
    if (!user) {
      toast.error("You must be logged in to view this content");
      navigate("/auth");
      return;
    }
    
    if (!contentType || !id) {
      toast.error("Invalid content request");
      navigate("/user-dashboard");
      return;
    }
    
    fetchContent();
  }, [contentType, id, user]);

  const fetchContent = async () => {
    try {
      setLoading(true);
      let data, error, authorData;
      
      switch (contentType) {
        case "post":
          const { data: postData, error: postError } = await supabase
            .from("blogs")
            .select("*")
            .eq("id", id)
            .single();
            
          data = postData;
          error = postError;
          
          if (data) {
            const { data: userData } = await supabase
              .from("profiles")
              .select("*")
              .eq("id", data.user_id)
              .single();
            authorData = userData;
          }
          break;
          
        case "event":
          const { data: eventData, error: eventError } = await supabase
            .from("events")
            .select("*")
            .eq("id", id)
            .single();
            
          data = eventData;
          error = eventError;
          
          if (data) {
            const { data: userData } = await supabase
              .from("profiles")
              .select("*")
              .eq("id", data.user_id)
              .single();
            authorData = userData;
          }
          break;
          
        case "trip":
          const { data: tripData, error: tripError } = await supabase
            .from("saved_trips")
            .select("*")
            .eq("id", id)
            .single();
            
          data = tripData;
          error = tripError;
          break;
          
        case "school-trip":
          const { data: schoolTripData, error: schoolTripError } = await supabase
            .from("school_trips")
            .select("*")
            .eq("id", id)
            .single();
            
          data = schoolTripData;
          error = schoolTripError;
          break;
          
        default:
          toast.error("Invalid content type");
          navigate("/user-dashboard");
          return;
      }
      
      if (error) {
        console.error("Error fetching content:", error);
        toast.error("Failed to load content details");
        navigate("/user-dashboard");
        return;
      }
      
      if (!data) {
        toast.error("Content not found");
        navigate("/user-dashboard");
        return;
      }
      
      setContent(data);
      if (authorData) {
        setAuthor(authorData);
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  const getInitials = (name: string) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  };
  
  const getContentTypeIcon = () => {
    switch (contentType) {
      case "post": return <User className="h-6 w-6" />;
      case "event": return <Calendar className="h-6 w-6" />;
      case "trip": return <Map className="h-6 w-6" />;
      case "school-trip": return <Map className="h-6 w-6" />;
      default: return <Info className="h-6 w-6" />;
    }
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="container mx-auto py-12 px-4">
          <Card className="overflow-hidden">
            <CardHeader>
              <div className="h-8 bg-gray-200 rounded w-1/2 mb-2 animate-pulse"></div>
              <div className="h-4 bg-gray-200 rounded w-1/3 animate-pulse"></div>
            </CardHeader>
            <div className="px-6 mb-6">
              <div className="h-64 bg-gray-200 rounded animate-pulse"></div>
            </div>
            <CardContent>
              <div className="h-4 bg-gray-200 rounded w-full mb-2 animate-pulse"></div>
              <div className="h-4 bg-gray-200 rounded w-full mb-2 animate-pulse"></div>
              <div className="h-4 bg-gray-200 rounded w-5/6 animate-pulse"></div>
            </CardContent>
          </Card>
        </div>
      );
    }
    
    switch (contentType) {
      case "post":
        return (
          <div className="container mx-auto py-12 px-4">
            <div className="mb-6">
              <Button 
                variant="ghost" 
                className="mb-4 pl-0" 
                onClick={() => navigate(-1)}
              >
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">{content.title}</h1>
              <div className="flex flex-wrap items-center gap-4 text-gray-600 mb-6">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="h-4 w-4" />
                  <span>{formatDate(content.created_at)}</span>
                </div>
                {content.location && (
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    <span>{content.location}</span>
                  </div>
                )}
              </div>
              
              {content.cover_image && (
                <div className="mb-8">
                  <img 
                    src={content.cover_image} 
                    alt={content.title} 
                    className="w-full h-64 md:h-96 object-cover rounded-lg shadow"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.onerror = null;
                      target.src = 'https://source.unsplash.com/random/800x400/?karnataka,india';
                    }}
                  />
                </div>
              )}
              
              <div className="prose max-w-none mb-8">
                <p className="whitespace-pre-line text-lg">{content.content}</p>
              </div>
              
              {author && (
                <div className="mt-12 pt-6 border-t">
                  <h3 className="text-lg font-semibold mb-4">Posted by</h3>
                  <div className="flex items-center gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={author.avatar_url} />
                      <AvatarFallback>{getInitials(author.full_name || author.username || 'User')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-medium">{author.full_name || author.username}</h4>
                      {author.bio && <p className="text-gray-600">{author.bio}</p>}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        );
        
      case "event":
        return (
          <div className="container mx-auto py-12 px-4">
            <Button 
              variant="ghost" 
              className="mb-4 pl-0" 
              onClick={() => navigate(-1)}
            >
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <h1 className="text-3xl md:text-4xl font-bold mb-2">{content.title}</h1>
                
                <div className="flex flex-wrap gap-3 mb-4">
                  <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                    Event
                  </Badge>
                  <Badge variant="outline">
                    {new Date(content.event_date).toLocaleDateString('en-US', { 
                      weekday: 'long',
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </Badge>
                </div>
                
                {content.cover_image && (
                  <div className="mb-8">
                    <img 
                      src={content.cover_image} 
                      alt={content.title} 
                      className="w-full h-64 object-cover rounded-lg"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.onerror = null;
                        target.src = 'https://source.unsplash.com/random/800x400/?event,karnataka';
                      }}
                    />
                  </div>
                )}
                
                <div className="prose max-w-none mb-8">
                  <h2 className="text-xl font-semibold mb-2">About this Event</h2>
                  <p className="whitespace-pre-line">{content.description}</p>
                </div>
                
                {author && (
                  <div className="mt-8 pt-6 border-t">
                    <h3 className="text-lg font-semibold mb-4">Organized by</h3>
                    <div className="flex items-center gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={author.avatar_url} />
                        <AvatarFallback>{getInitials(author.full_name || author.username || 'User')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="font-medium">{author.full_name || author.username}</h4>
                        {author.bio && <p className="text-gray-600">{author.bio}</p>}
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Event Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-3">
                      <CalendarIcon className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Date & Time</h4>
                        <p className="text-gray-600">
                          {new Date(content.event_date).toLocaleString('en-US', {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            hour: 'numeric',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Location</h4>
                        <p className="text-gray-600">{content.location}</p>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Join Event</Button>
                  </CardFooter>
                </Card>
                
                <div className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Location</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-[200px] bg-gray-100 rounded flex items-center justify-center">
                        <MapPin className="h-8 w-8 text-gray-400" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        );
        
      case "trip":
      case "school-trip":
        const tripPlaces = contentType === "trip" 
          ? (content.places ? content.places : [])
          : (content.places ? content.places : []);
          
        const placeNames = Array.isArray(tripPlaces) ? tripPlaces : [];
        
        return (
          <div className="container mx-auto py-12 px-4">
            <Button 
              variant="ghost" 
              className="mb-4 pl-0" 
              onClick={() => navigate(-1)}
            >
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <h1 className="text-3xl md:text-4xl font-bold mb-2">
                  {contentType === "trip" ? content.name : content.trip_name}
                </h1>
                
                <div className="flex flex-wrap gap-3 mb-6">
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
                    {contentType === "school-trip" ? "School Trip" : "Trip"}
                  </Badge>
                  {contentType === "school-trip" && (
                    <Badge variant="outline">
                      {content.status || 'Planning'}
                    </Badge>
                  )}
                  <Badge variant="outline">
                    {content.transport_mode || 'Not specified'}
                  </Badge>
                </div>
                
                {contentType === "school-trip" && (
                  <div className="mb-8">
                    <h2 className="text-xl font-semibold mb-2">About this Trip</h2>
                    <p className="whitespace-pre-line">{content.description || 'No description provided'}</p>
                    
                    <div className="mt-6 space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">School</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p>{content.school_name}</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Students</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p>{content.student_count} students</p>
                          </CardContent>
                        </Card>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Dates</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p>
                              {new Date(content.start_date).toLocaleDateString()} to{' '}
                              {new Date(content.end_date).toLocaleDateString()}
                            </p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-base">Budget</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p>{content.budget ? `₹${content.budget}` : 'Not specified'}</p>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                    
                    {content.requirements && (
                      <div className="mt-6">
                        <h3 className="text-lg font-semibold mb-2">Requirements</h3>
                        <p className="whitespace-pre-line">{content.requirements}</p>
                      </div>
                    )}
                  </div>
                )}
                
                <div className="mt-6">
                  <h2 className="text-xl font-semibold mb-4">Places to Visit</h2>
                  {placeNames.length > 0 ? (
                    <div className="space-y-4">
                      {placeNames.map((place: string, index: number) => (
                        <Card key={index}>
                          <CardHeader className="py-3">
                            <CardTitle className="text-base flex items-center">
                              <span className="bg-blue-100 text-blue-800 w-6 h-6 rounded-full flex items-center justify-center text-sm mr-3">
                                {index + 1}
                              </span>
                              {place}
                            </CardTitle>
                          </CardHeader>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-600">No places have been added to this trip.</p>
                  )}
                </div>
              </div>
              
              <div>
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>Trip Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Places</h4>
                        <p className="text-gray-600">{placeNames.length} destinations</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <Clock className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <h4 className="font-medium">Created</h4>
                        <p className="text-gray-600">{formatDate(content.created_at)}</p>
                      </div>
                    </div>
                    
                    {contentType === "trip" && content.total_distance && (
                      <div className="flex items-start gap-3">
                        <MapIcon className="h-5 w-5 text-gray-500 mt-0.5" />
                        <div>
                          <h4 className="font-medium">Total Distance</h4>
                          <p className="text-gray-600">{content.total_distance} km</p>
                        </div>
                      </div>
                    )}
                    
                    {contentType === "school-trip" && (
                      <div className="flex items-start gap-3">
                        <User className="h-5 w-5 text-gray-500 mt-0.5" />
                        <div>
                          <h4 className="font-medium">Trip Organizer</h4>
                          <p className="text-gray-600">School Administration</p>
                        </div>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">
                      Edit Trip
                    </Button>
                  </CardFooter>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Trip Map</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {placeNames.length > 0 ? (
                      <MapBox selectedLocations={placeNames} />
                    ) : (
                      <div className="h-[200px] bg-gray-100 rounded flex items-center justify-center">
                        <MapPin className="h-8 w-8 text-gray-400" />
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );
        
      default:
        return (
          <div className="container mx-auto py-12 px-4">
            <Card>
              <CardContent className="py-12">
                <div className="text-center">
                  <Info className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <h2 className="text-2xl font-bold mb-2">Content Not Available</h2>
                  <p className="text-gray-600 mb-6">The requested content could not be displayed.</p>
                  <Button onClick={() => navigate("/user-dashboard")}>
                    Return to Dashboard
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <NavbarUpdated />
      
      <div className="flex-grow">
        <div className="bg-white py-3 border-b">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <a href="/" className="hover:text-blue-600">Home</a>
              <span>/</span>
              <a href="/user-dashboard" className="hover:text-blue-600">Dashboard</a>
              <span>/</span>
              <span className="text-gray-900 flex items-center">
                {getContentTypeIcon()}
                <span className="ml-1 capitalize">
                  {contentType === "post" ? "Travel Story" : 
                   contentType === "event" ? "Event" :
                   contentType === "trip" ? "Trip" : 
                   contentType === "school-trip" ? "School Trip" : 
                   "Content"}
                </span>
              </span>
            </div>
          </div>
        </div>
        
        {renderContent()}
      </div>
      
      <Footer />
    </div>
  );
};

export default ContentDetails;
