
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import NavbarUpdated from "@/components/NavbarUpdated";
import Footer from "@/components/Footer";
import InteractiveMap from "@/components/InteractiveMap";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Calendar, Map, MapPin, PenLine, Plus } from "lucide-react";
import { motion } from "framer-motion";

const UserDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("create");
  const [userContent, setUserContent] = useState({
    posts: [],
    events: [],
    trips: [],
    schoolTrips: []
  });
  const [loading, setLoading] = useState({
    posts: true,
    events: true,
    trips: true,
    schoolTrips: true
  });

  useEffect(() => {
    if (!user) {
      toast.error("Please log in to access your personal dashboard");
      navigate('/auth');
      return;
    }
    
    if (activeTab === "view") {
      fetchUserContent();
    }
  }, [user, navigate, activeTab]);

  const fetchUserContent = async () => {
    if (!user) return;
    
    try {
      // Fetch posts
      setLoading(prev => ({ ...prev, posts: true }));
      const { data: posts, error: postsError } = await supabase
        .from('blogs')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (postsError) {
        console.error('Error fetching posts:', postsError);
        toast.error('Failed to load your posts');
      } else {
        setUserContent(prev => ({ ...prev, posts: posts || [] }));
      }
      setLoading(prev => ({ ...prev, posts: false }));
      
      // Fetch events
      setLoading(prev => ({ ...prev, events: true }));
      const { data: events, error: eventsError } = await supabase
        .from('events')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (eventsError) {
        console.error('Error fetching events:', eventsError);
        toast.error('Failed to load your events');
      } else {
        setUserContent(prev => ({ ...prev, events: events || [] }));
      }
      setLoading(prev => ({ ...prev, events: false }));
      
      // Fetch saved trips
      setLoading(prev => ({ ...prev, trips: true }));
      const { data: trips, error: tripsError } = await supabase
        .from('saved_trips')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (tripsError) {
        console.error('Error fetching trips:', tripsError);
        toast.error('Failed to load your trips');
      } else {
        setUserContent(prev => ({ ...prev, trips: trips || [] }));
      }
      setLoading(prev => ({ ...prev, trips: false }));
      
      // Fetch school trips
      setLoading(prev => ({ ...prev, schoolTrips: true }));
      const { data: schoolTrips, error: schoolTripsError } = await supabase
        .from('school_trips')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (schoolTripsError) {
        console.error('Error fetching school trips:', schoolTripsError);
        toast.error('Failed to load your school trips');
      } else {
        setUserContent(prev => ({ ...prev, schoolTrips: schoolTrips || [] }));
      }
      setLoading(prev => ({ ...prev, schoolTrips: false }));
      
    } catch (error) {
      console.error('Error fetching content:', error);
      toast.error('Failed to load your content');
      setLoading({
        posts: false,
        events: false,
        trips: false,
        schoolTrips: false
      });
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.1 
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  if (!user) {
    return null; // Don't render anything if not authenticated
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 to-indigo-50">
      <NavbarUpdated />
      
      <div className="container mx-auto px-4 py-10 flex-grow">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 bg-gradient-to-r from-triptrove-blue to-purple-600 bg-clip-text text-transparent">
            Your Personal Travel Hub
          </h1>
          <p className="text-gray-600 mt-2">Create and manage your Karnataka travel experiences</p>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 gap-2">
            <TabsTrigger value="create" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              <span>Create</span>
            </TabsTrigger>
            <TabsTrigger value="plan" className="flex items-center gap-2">
              <Map className="h-4 w-4" />
              <span>Plan Trip</span>
            </TabsTrigger>
            <TabsTrigger value="view" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>My Content</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="create">
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid gap-6 md:grid-cols-2"
            >
              <motion.div variants={itemVariants}>
                <Card className="overflow-hidden hover:shadow-lg transition-all cursor-pointer h-full border-2 border-triptrove-blue/20 hover:border-triptrove-blue/60"
                  onClick={() => navigate('/create-post')}>
                  <div className="bg-gradient-to-r from-triptrove-blue to-blue-600 h-2"></div>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <PenLine className="h-5 w-5 mr-2 text-triptrove-blue" />
                      Create a Travel Post
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">Share your travel experiences, photos, and stories from your Karnataka adventures.</p>
                    <div className="flex gap-2 flex-wrap">
                      <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">Photos</span>
                      <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">Stories</span>
                      <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">Tips</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants}>
                <Card className="overflow-hidden hover:shadow-lg transition-all cursor-pointer h-full border-2 border-triptrove-terracotta/20 hover:border-triptrove-terracotta/60"
                  onClick={() => navigate('/create-event')}>
                  <div className="bg-gradient-to-r from-triptrove-terracotta to-red-500 h-2"></div>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Calendar className="h-5 w-5 mr-2 text-triptrove-terracotta" />
                      Create an Event
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">Organize meetups, tours, or group trips to explore Karnataka's attractions.</p>
                    <div className="flex gap-2 flex-wrap">
                      <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded">Meetups</span>
                      <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded">Tours</span>
                      <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded">Activities</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div variants={itemVariants} className="md:col-span-2">
                <Card className="overflow-hidden hover:shadow-lg transition-all cursor-pointer border-2 border-green-600/20 hover:border-green-600/60"
                  onClick={() => navigate('/school-trip-planner')}>
                  <div className="bg-gradient-to-r from-green-600 to-green-400 h-2"></div>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <MapPin className="h-5 w-5 mr-2 text-green-600" />
                      Plan School/College Trip
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">Create educational trips for schools and colleges with detailed itineraries and budgeting.</p>
                    <div className="flex gap-2 flex-wrap">
                      <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Educational</span>
                      <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Group Travel</span>
                      <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Budgeting</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          </TabsContent>

          <TabsContent value="plan">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Plan Your Karnataka Adventure</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6">
                  Select destinations on the interactive map to create your perfect travel itinerary.
                </p>
                <InteractiveMap />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="view">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-2xl">Your Content</CardTitle>
              </CardHeader>
              <CardContent className="space-y-8">
                {/* Travel Posts */}
                <div>
                  <h3 className="text-xl font-semibold mb-4 flex items-center">
                    <PenLine className="h-5 w-5 mr-2 text-triptrove-blue" />
                    Your Travel Posts
                  </h3>
                  
                  {loading.posts ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="h-24 bg-gray-100 animate-pulse rounded"></div>
                      ))}
                    </div>
                  ) : userContent.posts.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {userContent.posts.map((post: any) => (
                        <Card key={post.id} className="cursor-pointer hover:shadow-md transition-shadow"
                          onClick={() => navigate(`/post/${post.id}`)}>
                          <CardHeader className="py-3">
                            <CardTitle className="text-base truncate">{post.title}</CardTitle>
                            <p className="text-xs text-gray-500">
                              {new Date(post.created_at).toLocaleDateString()}
                            </p>
                          </CardHeader>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 bg-gray-50 rounded-lg">
                      <PenLine className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">You haven't created any travel posts yet.</p>
                      <Button 
                        variant="link" 
                        onClick={() => navigate('/create-post')}
                        className="mt-2"
                      >
                        Create Your First Post
                      </Button>
                    </div>
                  )}
                </div>
                
                {/* Events */}
                <div>
                  <h3 className="text-xl font-semibold mb-4 flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-triptrove-terracotta" />
                    Your Events
                  </h3>
                  
                  {loading.events ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="h-24 bg-gray-100 animate-pulse rounded"></div>
                      ))}
                    </div>
                  ) : userContent.events.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {userContent.events.map((event: any) => (
                        <Card key={event.id} className="cursor-pointer hover:shadow-md transition-shadow"
                          onClick={() => navigate(`/event/${event.id}`)}>
                          <CardHeader className="py-3">
                            <CardTitle className="text-base truncate">{event.title}</CardTitle>
                            <p className="text-xs text-gray-500">
                              {new Date(event.event_date).toLocaleDateString()}
                            </p>
                          </CardHeader>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 bg-gray-50 rounded-lg">
                      <Calendar className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">You haven't created any events yet.</p>
                      <Button 
                        variant="link" 
                        onClick={() => navigate('/create-event')}
                        className="mt-2"
                      >
                        Create Your First Event
                      </Button>
                    </div>
                  )}
                </div>
                
                {/* Saved Trips */}
                <div>
                  <h3 className="text-xl font-semibold mb-4 flex items-center">
                    <Map className="h-5 w-5 mr-2 text-blue-600" />
                    Your Saved Trips
                  </h3>
                  
                  {loading.trips ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="h-24 bg-gray-100 animate-pulse rounded"></div>
                      ))}
                    </div>
                  ) : userContent.trips.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {userContent.trips.map((trip: any) => (
                        <Card key={trip.id} className="cursor-pointer hover:shadow-md transition-shadow"
                          onClick={() => navigate(`/trip/${trip.id}`)}>
                          <CardHeader className="py-3">
                            <CardTitle className="text-base truncate">{trip.name}</CardTitle>
                            <p className="text-xs text-gray-500">
                              {new Date(trip.created_at).toLocaleDateString()}
                            </p>
                          </CardHeader>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 bg-gray-50 rounded-lg">
                      <Map className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">You haven't created any trips yet.</p>
                      <Button 
                        variant="link" 
                        onClick={() => setActiveTab('plan')}
                        className="mt-2"
                      >
                        Plan Your First Trip
                      </Button>
                    </div>
                  )}
                </div>
                
                {/* School Trips */}
                <div>
                  <h3 className="text-xl font-semibold mb-4 flex items-center">
                    <MapPin className="h-5 w-5 mr-2 text-green-600" />
                    Your School Trips
                  </h3>
                  
                  {loading.schoolTrips ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="h-24 bg-gray-100 animate-pulse rounded"></div>
                      ))}
                    </div>
                  ) : userContent.schoolTrips.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {userContent.schoolTrips.map((trip: any) => (
                        <Card key={trip.id} className="cursor-pointer hover:shadow-md transition-shadow"
                          onClick={() => navigate(`/school-trip/${trip.id}`)}>
                          <CardHeader className="py-3">
                            <CardTitle className="text-base truncate">{trip.trip_name}</CardTitle>
                            <p className="text-xs text-gray-500">
                              {new Date(trip.created_at).toLocaleDateString()}
                            </p>
                          </CardHeader>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6 bg-gray-50 rounded-lg">
                      <MapPin className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600">You haven't created any school trips yet.</p>
                      <Button 
                        variant="link" 
                        onClick={() => navigate('/school-trip-planner')}
                        className="mt-2"
                      >
                        Create Your First School Trip
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      <Footer />
    </div>
  );
};

export default UserDashboard;
