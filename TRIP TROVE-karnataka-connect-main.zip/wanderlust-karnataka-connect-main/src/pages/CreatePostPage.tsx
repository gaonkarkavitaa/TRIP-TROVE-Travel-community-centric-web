
import CreatePost from "@/components/CreatePost";
import NavbarUpdated from "@/components/NavbarUpdated";
import Footer from "@/components/Footer";

const CreatePostPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <NavbarUpdated />
      <main className="flex-grow py-8">
        <CreatePost />
      </main>
      <Footer />
    </div>
  );
};

export default CreatePostPage;
