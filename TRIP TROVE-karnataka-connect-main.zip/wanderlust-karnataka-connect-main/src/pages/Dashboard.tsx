
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import NavbarUpdated from "@/components/NavbarUpdated";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { Plus, MapPin, Calendar, PenLine, Book, Map, School } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { motion } from "framer-motion";
import { AspectRatio } from "@/components/ui/aspect-ratio";

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("posts");
  const [userPosts, setUserPosts] = useState<any[]>([]);
  const [userEvents, setUserEvents] = useState<any[]>([]);
  const [savedTrips, setSavedTrips] = useState<any[]>([]);
  const [schoolTrips, setSchoolTrips] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      toast.error("Please log in to view your dashboard");
      navigate('/auth');
      return;
    }

    const fetchUserContent = async () => {
      setLoading(true);
      try {
        // Fetch user's blog posts
        const { data: posts, error: postsError } = await supabase
          .from('blogs')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });
        
        if (postsError) throw postsError;
        setUserPosts(posts || []);
        
        // Fetch user's events
        const { data: events, error: eventsError } = await supabase
          .from('events')
          .select('*')
          .eq('user_id', user.id)
          .order('event_date', { ascending: true });
        
        if (eventsError) throw eventsError;
        setUserEvents(events || []);
        
        // Fetch user's saved trips
        const { data: trips, error: tripsError } = await supabase
          .from('saved_trips')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });
        
        if (tripsError) throw tripsError;
        setSavedTrips(trips || []);
        
        // Fetch user's school trips
        const { data: schoolTripData, error: schoolTripError } = await supabase
          .from('school_trips')
          .select('*')
          .eq('user_id', user.id)
          .order('start_date', { ascending: true });
        
        if (schoolTripError) throw schoolTripError;
        setSchoolTrips(schoolTripData || []);
        
      } catch (error: any) {
        console.error("Error fetching user content:", error);
        toast.error("Failed to load your content");
      } finally {
        setLoading(false);
      }
    };

    fetchUserContent();
  }, [user, navigate]);

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'planning':
        return 'bg-blue-100 text-blue-800';
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-purple-100 text-purple-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch (e) {
      return 'Invalid date';
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.1 
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <NavbarUpdated />
      
      <div className="container mx-auto px-4 py-10 flex-grow">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800">My Dashboard</h1>
          <p className="text-gray-600 mt-2">Manage your travel experiences and plans</p>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid grid-cols-4 mb-8">
            <TabsTrigger value="posts" className="flex items-center gap-2">
              <PenLine className="h-4 w-4" />
              <span className="hidden sm:inline">Posts</span>
              <Badge variant="secondary" className="ml-1">{userPosts.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="events" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">Events</span>
              <Badge variant="secondary" className="ml-1">{userEvents.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="trips" className="flex items-center gap-2">
              <Map className="h-4 w-4" />
              <span className="hidden sm:inline">Saved Trips</span>
              <Badge variant="secondary" className="ml-1">{savedTrips.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="schoolTrips" className="flex items-center gap-2">
              <School className="h-4 w-4" />
              <span className="hidden sm:inline">School Trips</span>
              <Badge variant="secondary" className="ml-1">{schoolTrips.length}</Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="posts">
            <div className="grid gap-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-semibold text-gray-800">Your Posts</h2>
                <Button onClick={() => navigate('/create-post')} className="bg-triptrove-blue hover:bg-triptrove-blue/90">
                  <Plus className="mr-2 h-4 w-4" />
                  New Post
                </Button>
              </div>

              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3].map(i => (
                    <Card key={i} className="animate-pulse">
                      <div className="h-48 bg-gray-200"></div>
                      <CardContent className="p-4">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-full mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-4/5"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : userPosts.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center p-12 text-center">
                    <Book className="h-16 w-16 text-gray-400 mb-4" />
                    <h3 className="text-xl font-medium text-gray-800">No Posts Yet</h3>
                    <p className="text-gray-500 mb-6">Share your travel experiences and stories with the community.</p>
                    <Button onClick={() => navigate('/create-post')} className="bg-triptrove-blue hover:bg-triptrove-blue/90">
                      Create Your First Post
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                >
                  {userPosts.map((post) => (
                    <motion.div key={post.id} variants={itemVariants}>
                      <Card className="overflow-hidden hover:shadow-lg transition-all cursor-pointer" 
                        onClick={() => navigate(`/blogs/${post.id}`)}>
                        <AspectRatio ratio={16/9}>
                          <img 
                            src={post.cover_image || `https://via.placeholder.com/600x400/1A4D8C/FFFFFF?text=${post.title}`}
                            alt={post.title}
                            className="w-full h-full object-cover"
                          />
                        </AspectRatio>
                        <CardContent className="p-5">
                          <h3 className="text-lg font-semibold mb-2 text-gray-800 line-clamp-2">{post.title}</h3>
                          <div className="flex items-center text-sm text-gray-500 mb-3">
                            <MapPin className="h-3.5 w-3.5 mr-1" />
                            {post.location || "No location specified"}
                          </div>
                          <p className="text-gray-600 text-sm line-clamp-3">
                            {post.content?.substring(0, 150)}...
                          </p>
                          <div className="flex justify-between items-center mt-4">
                            <span className="text-xs text-gray-500">
                              {formatDate(post.created_at)}
                            </span>
                            <Button size="sm" variant="ghost" className="text-triptrove-blue">
                              Read More
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="events">
            {/* Similar layout for events tab */}
            <div className="grid gap-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-semibold text-gray-800">Your Events</h2>
                <Button onClick={() => navigate('/create-event')} className="bg-triptrove-blue hover:bg-triptrove-blue/90">
                  <Plus className="mr-2 h-4 w-4" />
                  New Event
                </Button>
              </div>

              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[1, 2].map(i => (
                    <Card key={i} className="animate-pulse">
                      <div className="h-48 bg-gray-200"></div>
                      <CardContent className="p-4">
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-full mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-4/5"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : userEvents.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center p-12 text-center">
                    <Calendar className="h-16 w-16 text-gray-400 mb-4" />
                    <h3 className="text-xl font-medium text-gray-800">No Events Yet</h3>
                    <p className="text-gray-500 mb-6">Create and host your travel events or meetups.</p>
                    <Button onClick={() => navigate('/create-event')} className="bg-triptrove-blue hover:bg-triptrove-blue/90">
                      Create Your First Event
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="grid grid-cols-1 md:grid-cols-2 gap-6"
                >
                  {userEvents.map((event) => (
                    <motion.div key={event.id} variants={itemVariants}>
                      <Card className="overflow-hidden hover:shadow-lg transition-all cursor-pointer"
                        onClick={() => navigate(`/events/${event.id}`)}>
                        <div className="relative">
                          <AspectRatio ratio={16/9}>
                            <img 
                              src={event.cover_image || `https://via.placeholder.com/600x400/1A4D8C/FFFFFF?text=${event.title}`}
                              alt={event.title}
                              className="w-full h-full object-cover"
                            />
                          </AspectRatio>
                          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                            <div className="inline-block bg-white rounded-full px-3 py-1 text-sm font-medium">
                              {formatDate(event.event_date)}
                            </div>
                          </div>
                        </div>
                        <CardContent className="p-5">
                          <h3 className="text-lg font-semibold mb-2 text-gray-800">{event.title}</h3>
                          <div className="flex items-center text-sm text-gray-500 mb-3">
                            <MapPin className="h-3.5 w-3.5 mr-1" />
                            {event.location}
                          </div>
                          <p className="text-gray-600 text-sm line-clamp-2">
                            {event.description}
                          </p>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="trips">
            {/* Content for saved trips */}
            <div className="grid gap-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-semibold text-gray-800">Your Saved Trips</h2>
                <Button onClick={() => navigate('/explore')} className="bg-triptrove-blue hover:bg-triptrove-blue/90">
                  <Plus className="mr-2 h-4 w-4" />
                  Plan New Trip
                </Button>
              </div>

              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-4">
                        <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
                        <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : savedTrips.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center p-12 text-center">
                    <Map className="h-16 w-16 text-gray-400 mb-4" />
                    <h3 className="text-xl font-medium text-gray-800">No Saved Trips</h3>
                    <p className="text-gray-500 mb-6">Plan your journey and save trips for future reference.</p>
                    <Button onClick={() => navigate('/explore')} className="bg-triptrove-blue hover:bg-triptrove-blue/90">
                      Plan Your First Trip
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {savedTrips.map((trip) => (
                    <motion.div key={trip.id} variants={itemVariants}>
                      <Card className="hover:shadow-md transition-all">
                        <CardContent className="p-5">
                          <div className="flex flex-col md:flex-row justify-between">
                            <div className="mb-4 md:mb-0">
                              <h3 className="text-lg font-semibold text-gray-800">{trip.name}</h3>
                              <div className="flex items-center text-sm text-gray-500 mt-1">
                                <Badge variant="outline" className="mr-2">
                                  {trip.transport_mode}
                                </Badge>
                                {trip.total_distance && (
                                  <span>{Math.round(trip.total_distance)} km</span>
                                )}
                              </div>
                            </div>
                            <Button 
                              variant="outline" 
                              className="text-triptrove-blue border-triptrove-blue"
                              onClick={() => navigate(`/trips/${trip.id}`)}
                            >
                              View Details
                            </Button>
                          </div>
                          <div className="mt-4">
                            <h4 className="text-sm font-medium text-gray-700 mb-2">Places:</h4>
                            <div className="flex flex-wrap gap-2">
                              {trip.places && Array.isArray(trip.places) && trip.places.map((place, idx) => (
                                <Badge key={idx} variant="secondary">
                                  {place}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="schoolTrips">
            {/* Content for school trips */}
            <div className="grid gap-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-semibold text-gray-800">School Trips</h2>
                <Button onClick={() => navigate('/school-trip-planner')} className="bg-triptrove-blue hover:bg-triptrove-blue/90">
                  <Plus className="mr-2 h-4 w-4" />
                  Plan School Trip
                </Button>
              </div>

              {loading ? (
                <div className="space-y-4">
                  {[1, 2].map(i => (
                    <Card key={i} className="animate-pulse">
                      <CardContent className="p-4">
                        <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
                        <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : schoolTrips.length === 0 ? (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center p-12 text-center">
                    <School className="h-16 w-16 text-gray-400 mb-4" />
                    <h3 className="text-xl font-medium text-gray-800">No School Trips Planned</h3>
                    <p className="text-gray-500 mb-6">Plan educational trips for your school or college students.</p>
                    <Button onClick={() => navigate('/school-trip-planner')} className="bg-triptrove-blue hover:bg-triptrove-blue/90">
                      Plan Your First School Trip
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  className="space-y-4"
                >
                  {schoolTrips.map((trip) => (
                    <motion.div key={trip.id} variants={itemVariants}>
                      <Card className="hover:shadow-md transition-all">
                        <CardContent className="p-5">
                          <div className="flex flex-col md:flex-row justify-between">
                            <div>
                              <div className="flex items-center gap-2 mb-2">
                                <h3 className="text-lg font-semibold text-gray-800">{trip.trip_name}</h3>
                                <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusColor(trip.status)}`}>
                                  {trip.status || 'Planning'}
                                </span>
                              </div>
                              <p className="text-sm text-gray-600 mb-1">
                                <span className="font-medium">School:</span> {trip.school_name}
                              </p>
                              <p className="text-sm text-gray-600">
                                <span className="font-medium">Dates:</span> {formatDate(trip.start_date)} to {formatDate(trip.end_date)}
                              </p>
                              <div className="flex items-center text-sm text-gray-500 mt-2">
                                <Badge variant="outline" className="mr-2">
                                  {trip.transport_mode}
                                </Badge>
                                <span>{trip.student_count} students</span>
                              </div>
                            </div>
                            <Button 
                              className="mt-4 md:mt-0 bg-triptrove-blue hover:bg-triptrove-blue/90"
                              onClick={() => navigate(`/school-trips/${trip.id}`)}
                            >
                              View Details
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      <Footer />
    </div>
  );
};

export default Dashboard;
