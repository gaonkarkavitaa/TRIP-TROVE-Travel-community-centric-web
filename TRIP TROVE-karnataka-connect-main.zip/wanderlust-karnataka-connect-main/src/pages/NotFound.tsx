
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { MapPin } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center p-8">
        <div className="flex justify-center mb-6">
          <div className="bg-triptrove-blue/10 p-4 rounded-full">
            <MapPin className="h-16 w-16 text-triptrove-blue" />
          </div>
        </div>
        <h1 className="text-6xl font-bold text-triptrove-blue mb-4">404</h1>
        <p className="text-2xl text-gray-700 mb-6">You seem to be off the map!</p>
        <p className="text-gray-600 max-w-md mx-auto mb-8">
          The page you're looking for doesn't exist or has been moved to another location.
        </p>
        <div className="space-x-4">
          <Link to="/">
            <Button className="triptrove-btn-primary">
              Back to Homepage
            </Button>
          </Link>
          <Link to="/explore">
            <Button variant="outline">
              Explore Karnataka
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
