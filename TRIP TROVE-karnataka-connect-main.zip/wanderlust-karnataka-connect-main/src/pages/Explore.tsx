
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, Search, Info } from "lucide-react";
import NavbarUpdated from '@/components/NavbarUpdated';
import Footer from '@/components/Footer';
import MapBox from '@/components/MapBox';
import { Link } from "react-router-dom";
import { toast } from "sonner";
import InteractiveMap from '@/components/InteractiveMap';

const Explore = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDestination, setSelectedDestination] = useState<string | null>(null);
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchQuery.trim()) {
      toast.warning("Please enter a search term");
      return;
    }
    
    // Find destination matching search query
    const match = popularDestinations.find(
      dest => dest.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    
    if (match) {
      setSelectedDestination(match.name);
      toast.success(`Found: ${match.name}`);
    } else {
      toast.error("No matching destinations found");
    }
  };

  const handleDestinationClick = (destinationName: string) => {
    toast.info(`Selected: ${destinationName}`);
    setSelectedDestination(destinationName);
    
    // Scroll to map section
    const mapSection = document.getElementById('map-section');
    if (mapSection) {
      mapSection.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <NavbarUpdated />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-triptrove-blue mb-4">Explore Karnataka</h1>
            <p className="text-lg text-gray-600 max-w-3xl">
              Discover the hidden gems, popular attractions, and plan your next adventure through our interactive map.
            </p>
          </div>
          
          <div className="mb-8">
            <form onSubmit={handleSearch} className="relative max-w-xl">
              <Input
                placeholder="Search for places in Karnataka..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 py-6 text-lg"
              />
              <Button
                type="submit"
                variant="ghost" 
                size="icon"
                className="absolute right-0 top-0 h-full"
              >
                <Search className="h-5 w-5" />
              </Button>
            </form>
          </div>
          
          <div id="map-section" className="bg-white rounded-lg shadow-md p-4 mb-8">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <MapPin className="mr-2 text-triptrove-terracotta" />
              Interactive Map & Trip Planning
            </h2>
            <div className="rounded-lg overflow-hidden">
              <InteractiveMap />
            </div>
          </div>
          
          <div className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Popular Destinations</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {popularDestinations.map((destination) => (
                <DestinationCard 
                  key={destination.id}
                  name={destination.name}
                  image={destination.image}
                  description={destination.description}
                  onClick={() => handleDestinationClick(destination.name)}
                />
              ))}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

interface DestinationCardProps {
  name: string;
  image: string;
  description: string;
  onClick?: () => void;
}

const DestinationCard = ({ name, image, description, onClick }: DestinationCardProps) => {
  return (
    <div className="border rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      <img 
        src={image} 
        alt={name} 
        className="w-full h-48 object-cover"
        onError={(e) => {
          const target = e.target as HTMLImageElement;
          target.onerror = null;
          target.src = 'https://source.unsplash.com/random/300x200/?karnataka';
        }}
      />
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2">{name}</h3>
        <p className="text-gray-600 text-sm mb-3 line-clamp-3">{description}</p>
        <Button variant="outline" size="sm" className="w-full" onClick={onClick}>
          View Details
        </Button>
      </div>
    </div>
  );
};

const popularDestinations = [
  {
    id: 1,
    name: "Mysore Palace",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/06/Mysuru-Palace-2-scaled.jpg",
    description: "The Mysore Palace is a historical palace and the official residence of the Wadiyar dynasty and the seat of the Kingdom of Mysore."
  },
  {
    id: 2,
    name: "Hampi",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/05/Hampi-Stone-Chariot-scaled.jpg",
    description: "Hampi is an ancient village in the south Indian state of Karnataka. It's dotted with numerous ruined temple complexes from the Vijayanagara Empire."
  },
  {
    id: 3,
    name: "Jog Falls",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/05/JOG-scaled.jpg",
    description: "Jog Falls is the second-highest plunge waterfall in India, Located in Shimoga district and formed by the Sharavathi River."
  },
  {
    id: 4,
    name: "Coorg",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/06/Abbey-falls-2-scaled.jpg",
    description: "Coorg, officially known as Kodagu, is a rural district in the southwest Indian state of Karnataka, known for coffee plantations and beautiful landscapes."
  },
  {
    id: 5,
    name: "Gokarna",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/06/Gokarna-Beach-scaled.jpg",
    description: "Gokarna is a town on the Arabian Sea, in the southwestern state of Karnataka. A popular pilgrimage destination with beautiful beaches."
  },
  {
    id: 6,
    name: "Bandipur National Park",
    image: "https://karnatakatourism.org/wp-content/uploads/2020/06/Bandipur-1-scaled.jpg", 
    description: "Bandipur National Park, established in 1974, is a beautiful wildlife sanctuary located in the state of Karnataka."
  }
];

export default Explore;
