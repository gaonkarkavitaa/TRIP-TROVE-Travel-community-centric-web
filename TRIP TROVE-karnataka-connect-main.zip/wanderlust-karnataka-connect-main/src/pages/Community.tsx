
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import NavbarUpdated from "@/components/NavbarUpdated";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MapPin, Calendar, Users, MessageCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";

const Community = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [blogs, setBlogs] = useState([]);
  const [events, setEvents] = useState([]);
  const [discussions, setDiscussions] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      
      try {
        // Fetch blogs
        const { data: blogsData, error: blogsError } = await supabase
          .from('blogs')
          .select(`
            *,
            profiles:user_id (username, avatar_url, full_name)
          `)
          .order('created_at', { ascending: false })
          .limit(10);
          
        if (blogsError) throw blogsError;
        setBlogs(blogsData || []);
        
        // Fetch events
        const { data: eventsData, error: eventsError } = await supabase
          .from('events')
          .select(`
            *,
            profiles:user_id (username, avatar_url, full_name),
            participants:event_participants (user_id)
          `)
          .order('event_date', { ascending: true })
          .limit(10);
          
        if (eventsError) throw eventsError;
        setEvents(eventsData || []);
        
        // Fetch discussions
        const { data: discussionsData, error: discussionsError } = await supabase
          .from('discussions')
          .select(`
            *,
            profiles:user_id (username, avatar_url, full_name),
            comments:comments (id)
          `)
          .order('updated_at', { ascending: false })
          .limit(10);
          
        if (discussionsError) throw discussionsError;
        setDiscussions(discussionsData || []);
        
      } catch (error) {
        console.error("Error fetching community data:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  const handleCreatePost = () => {
    navigate('/create-post');
  };
  
  const handleCreateEvent = () => {
    navigate('/create-event');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavbarUpdated />
      
      <main className="flex-grow py-8">
        <div className="triptrove-container">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-triptrove-blue">Karnataka Travel Community</h1>
            
            <div className="flex gap-4">
              <Button onClick={handleCreatePost} className="triptrove-btn-primary">
                Share Experience
              </Button>
              <Button onClick={handleCreateEvent} className="triptrove-btn-secondary">
                Create Event
              </Button>
            </div>
          </div>
          
          <Tabs defaultValue="blogs" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="blogs">Travel Stories</TabsTrigger>
              <TabsTrigger value="events">Community Events</TabsTrigger>
              <TabsTrigger value="discussions">Discussions</TabsTrigger>
            </TabsList>
            
            <TabsContent value="blogs" className="mt-6">
              {loading ? (
                <div className="text-center py-12">Loading stories...</div>
              ) : blogs.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {blogs.map((blog) => (
                    <BlogCard key={blog.id} blog={blog} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500 mb-4">No travel stories yet.</p>
                  <Button onClick={handleCreatePost} className="triptrove-btn-primary">
                    Share Your First Experience
                  </Button>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="events" className="mt-6">
              {loading ? (
                <div className="text-center py-12">Loading events...</div>
              ) : events.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {events.map((event) => (
                    <EventCard key={event.id} event={event} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500 mb-4">No events scheduled.</p>
                  <Button onClick={handleCreateEvent} className="triptrove-btn-secondary">
                    Create the First Event
                  </Button>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="discussions" className="mt-6">
              {loading ? (
                <div className="text-center py-12">Loading discussions...</div>
              ) : discussions.length > 0 ? (
                <div className="space-y-6">
                  {discussions.map((discussion) => (
                    <DiscussionCard key={discussion.id} discussion={discussion} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500">No discussions yet.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

const BlogCard = ({ blog }) => {
  const navigate = useNavigate();
  
  return (
    <Card className="overflow-hidden hover:shadow-md transition-all">
      {blog.cover_image && (
        <div className="h-48 overflow-hidden">
          <img src={blog.cover_image} alt={blog.title} className="w-full h-full object-cover" />
        </div>
      )}
      <CardHeader>
        <CardTitle className="line-clamp-2">{blog.title}</CardTitle>
        <CardDescription className="flex items-center">
          {blog.location && (
            <>
              <MapPin className="h-4 w-4 mr-1" /> 
              <span>{blog.location}</span>
            </>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-gray-700 line-clamp-3">{blog.content}</p>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <div className="flex items-center">
          <Avatar className="h-6 w-6 mr-2">
            <AvatarImage src={blog.profiles?.avatar_url} />
            <AvatarFallback>{blog.profiles?.full_name?.charAt(0) || blog.profiles?.username?.charAt(0) || 'U'}</AvatarFallback>
          </Avatar>
          <span className="text-sm text-gray-600">{blog.profiles?.full_name || blog.profiles?.username}</span>
        </div>
        <Button variant="ghost" size="sm" onClick={() => navigate(`/blog/${blog.id}`)}>
          Read More
        </Button>
      </CardFooter>
    </Card>
  );
};

const EventCard = ({ event }) => {
  const navigate = useNavigate();
  
  return (
    <Card className="overflow-hidden hover:shadow-md transition-all">
      {event.cover_image && (
        <div className="h-48 overflow-hidden">
          <img src={event.cover_image} alt={event.title} className="w-full h-full object-cover" />
        </div>
      )}
      <CardHeader>
        <CardTitle className="line-clamp-2">{event.title}</CardTitle>
        <CardDescription className="flex items-center">
          <MapPin className="h-4 w-4 mr-1" /> 
          <span>{event.location}</span>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center text-sm text-gray-600 mb-3">
          <Calendar className="h-4 w-4 mr-1" />
          <span>
            {event.event_date ? format(new Date(event.event_date), 'PPP') : 'Date TBA'}
          </span>
        </div>
        <p className="text-gray-700 line-clamp-3">{event.description}</p>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <div className="flex items-center">
          <Users className="h-4 w-4 mr-1 text-gray-500" />
          <span className="text-sm text-gray-600">
            {event.participants?.length || 0} joined
          </span>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          className="border-triptrove-blue text-triptrove-blue"
          onClick={() => navigate(`/event/${event.id}`)}
        >
          View Event
        </Button>
      </CardFooter>
    </Card>
  );
};

const DiscussionCard = ({ discussion }) => {
  const navigate = useNavigate();
  
  return (
    <Card className="hover:shadow-sm transition-all">
      <CardHeader>
        <div className="flex justify-between">
          <CardTitle className="text-xl">{discussion.title}</CardTitle>
          <span className="text-xs text-white bg-triptrove-terracotta px-2 py-1 rounded-full">
            {discussion.category}
          </span>
        </div>
        <div className="flex items-center">
          <Avatar className="h-6 w-6 mr-2">
            <AvatarImage src={discussion.profiles?.avatar_url} />
            <AvatarFallback>{discussion.profiles?.full_name?.charAt(0) || discussion.profiles?.username?.charAt(0) || 'U'}</AvatarFallback>
          </Avatar>
          <CardDescription>
            Posted by {discussion.profiles?.full_name || discussion.profiles?.username}
          </CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-gray-700 line-clamp-2">{discussion.content}</p>
      </CardContent>
      <CardFooter className="flex justify-between items-center">
        <div className="flex items-center">
          <MessageCircle className="h-4 w-4 mr-1 text-gray-500" />
          <span className="text-sm text-gray-600">
            {discussion.comments?.length || 0} replies
          </span>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate(`/discussion/${discussion.id}`)}
        >
          Join Conversation
        </Button>
      </CardFooter>
    </Card>
  );
};

export default Community;
