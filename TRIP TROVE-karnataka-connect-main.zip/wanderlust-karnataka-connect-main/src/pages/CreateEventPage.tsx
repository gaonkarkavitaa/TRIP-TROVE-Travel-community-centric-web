
import CreateEvent from "@/components/CreateEvent";
import NavbarUpdated from "@/components/NavbarUpdated";
import Footer from "@/components/Footer";

const CreateEventPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <NavbarUpdated />
      <main className="flex-grow py-8">
        <CreateEvent />
      </main>
      <Footer />
    </div>
  );
};

export default CreateEventPage;
