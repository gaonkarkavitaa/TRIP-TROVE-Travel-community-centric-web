
import NavbarUpdated from "@/components/NavbarUpdated";
import HeroUpdated from "@/components/HeroUpdated";
import FeaturedPlaces from "@/components/FeaturedPlaces";
import InteractiveMap from "@/components/InteractiveMap";
import TravelStories from "@/components/TravelStories";
import CommunityHighlights from "@/components/CommunityHighlights";
import Footer from "@/components/Footer";
import { MapPin, Users, Map as MapIcon, Calendar, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";

const Index = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleExploreClick = () => {
    navigate('/explore');
  };

  const handleCommunityClick = () => {
    navigate('/community');
  };
  
  const handleCreatePostClick = () => {
    if (user) {
      navigate('/create-post');
    } else {
      navigate('/auth');
    }
  };
  
  const handleCreateEventClick = () => {
    if (user) {
      navigate('/create-event');
    } else {
      navigate('/auth');
    }
  };
  
  const handlePlanTripClick = () => {
    if (user) {
      navigate('/school-trip-planner');
    } else {
      navigate('/auth');
    }
  };

  const handleAuthAction = () => {
    navigate('/auth');
  };

  const handleDashboardAction = () => {
    navigate('/user-dashboard');
  };

  return (
    <div className="min-h-screen flex flex-col">
      <NavbarUpdated />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <HeroUpdated />
        
        {/* Main Content */}
        <div className="triptrove-container px-4 mx-auto max-w-7xl">
          {/* Features Section */}
          <section className="py-16">
            <h2 className="text-3xl font-bold text-triptrove-blue text-center mb-12">
              Explore Karnataka Like Never Before
            </h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              <FeatureCard 
                icon={<MapPin className="h-10 w-10 text-triptrove-blue" />}
                title="Interactive Map"
                description="Select any location in Karnataka and begin planning your adventure with our interactive map."
                onClick={handleExploreClick}
              />
              <FeatureCard 
                icon={<MapIcon className="h-10 w-10 text-triptrove-terracotta" />}
                title="Optimal Routes"
                description="Our intelligent system calculates the most efficient route between your selected destinations."
                onClick={handleExploreClick}
              />
              <FeatureCard 
                icon={<Users className="h-10 w-10 text-triptrove-green" />}
                title="Community Connect"
                description="Join forums, share experiences, and connect with fellow travelers passionate about Karnataka."
                onClick={handleCommunityClick}
              />
              <FeatureCard 
                icon={<BookOpen className="h-10 w-10 text-triptrove-gold" />}
                title="Travel Stories"
                description="Read and share detailed travel blogs and tips from real experiences across Karnataka."
                onClick={handleCreatePostClick}
              />
            </div>
          </section>
          
          {/* Featured Places */}
          <FeaturedPlaces />
          
          {/* Travel Stories - Modified to show public posts */}
          <section className="py-16">
            <div className="mb-8 text-center">
              <h2 className="text-3xl font-bold text-triptrove-blue mb-4">
                Travel Stories From Our Community
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Explore Karnataka through the eyes of fellow travelers and get inspired for your next adventure
              </p>
            </div>
            
            <TravelStories />
          </section>
          
          {/* Community Highlights */}
          <CommunityHighlights />
          
          {/* Interactive Map Section */}
          <section className="py-16">
            <h2 className="text-3xl font-bold text-triptrove-blue mb-8">
              Plan Your Journey
            </h2>
            <p className="text-lg mb-8 max-w-3xl">
              Select places on our interactive map, and we'll help you find the optimal route with distance calculations and transportation options.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <Button 
                className="bg-triptrove-blue hover:bg-triptrove-blue/90 text-white text-lg py-6" 
                onClick={handleExploreClick}
              >
                Explore Map
              </Button>
              <Button 
                className="bg-triptrove-terracotta hover:bg-triptrove-terracotta/90 text-white text-lg py-6"
                onClick={handlePlanTripClick}
              >
                Plan School Trip
              </Button>
            </div>
            
            <InteractiveMap />
          </section>
          
          {/* Call to Action */}
          <section className="py-16 text-center">
            <div className="max-w-3xl mx-auto bg-gradient-to-r from-triptrove-blue to-blue-800 rounded-2xl p-8 text-white">
              <h2 className="text-3xl font-bold mb-4">Join Our Growing Community</h2>
              <p className="text-lg mb-6">
                Create your profile, participate in discussions, share your travel stories, and connect with fellow explorers.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {user ? (
                  <>
                    <Button 
                      className="bg-white text-triptrove-blue hover:bg-white/90 text-lg px-8 py-3"
                      onClick={handleDashboardAction}
                    >
                      Your Dashboard
                    </Button>
                    <Button 
                      className="bg-triptrove-terracotta text-white hover:bg-triptrove-terracotta/90 text-lg px-8 py-3"
                      onClick={handleCreateEventClick}
                    >
                      Create an Event
                    </Button>
                  </>
                ) : (
                  <>
                    <Button 
                      className="bg-white text-triptrove-blue hover:bg-white/90 text-lg px-8 py-3"
                      onClick={handleAuthAction}
                    >
                      Sign Up Now
                    </Button>
                    <Button 
                      className="bg-triptrove-terracotta text-white hover:bg-triptrove-terracotta/90 text-lg px-8 py-3"
                      onClick={handleAuthAction}
                    >
                      Join Community
                    </Button>
                  </>
                )}
              </div>
            </div>
          </section>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

const FeatureCard = ({ 
  icon, 
  title, 
  description,
  onClick
}: { 
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick?: () => void;
}) => {
  return (
    <div 
      className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-all flex flex-col items-center text-center cursor-pointer"
      onClick={onClick}
    >
      <div className="mb-4 p-3 bg-gray-50 rounded-full">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default Index;
