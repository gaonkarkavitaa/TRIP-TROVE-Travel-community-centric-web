
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DatePicker } from "@/components/ui/date-picker";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import MapBox from "@/components/MapBox";
import { karnatakaTouristSpots } from "@/data/karnataka-data";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Calendar, School, Users, Trash, Route, Bus, Train, Car, Info } from "lucide-react";

const SchoolTripPlanner = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [schoolName, setSchoolName] = useState("");
  const [tripName, setTripName] = useState("");
  const [description, setDescription] = useState("");
  const [selectedPlaces, setSelectedPlaces] = useState<string[]>([]);
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [studentCount, setStudentCount] = useState<number>(0);
  const [transportMode, setTransportMode] = useState<string>("");
  const [budget, setBudget] = useState<number | "">("");
  const [requirements, setRequirements] = useState("");

  const handlePlaceSelect = (place: string) => {
    if (selectedPlaces.includes(place)) {
      setSelectedPlaces(selectedPlaces.filter(p => p !== place));
    } else {
      if (selectedPlaces.length >= 10) {
        toast.warning("You can select up to 10 places for one trip");
        return;
      }
      setSelectedPlaces([...selectedPlaces, place]);
    }
  };

  const handleRemovePlace = (place: string) => {
    setSelectedPlaces(selectedPlaces.filter(p => p !== place));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error("You must be logged in to create a trip");
      navigate("/auth");
      return;
    }
    
    if (selectedPlaces.length < 2) {
      toast.error("Please select at least 2 places for your trip");
      return;
    }
    
    if (!startDate || !endDate) {
      toast.error("Please select both start and end dates");
      return;
    }
    
    if (endDate < startDate) {
      toast.error("End date cannot be before start date");
      return;
    }
    
    setLoading(true);
    
    try {
      // Fix TypeScript error by using the correct table name
      const { error } = await supabase
        .from('school_trips')
        .insert({
          user_id: user.id,
          school_name: schoolName,
          trip_name: tripName,
          description,
          places: selectedPlaces,
          start_date: startDate.toISOString(),
          end_date: endDate.toISOString(),
          student_count: studentCount,
          transport_mode: transportMode,
          budget: budget || null,
          requirements,
          status: 'planning'
        });
      
      if (error) throw error;
      
      toast.success("Trip created successfully!");
      
      // Reset form
      setSchoolName("");
      setTripName("");
      setDescription("");
      setSelectedPlaces([]);
      setStartDate(undefined);
      setEndDate(undefined);
      setStudentCount(0);
      setTransportMode("");
      setBudget("");
      setRequirements("");
      
    } catch (error: any) {
      toast.error(error.message || "Failed to create trip");
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="container mx-auto my-16 px-4">
        <Alert className="mb-8">
          <AlertCircle className="h-5 w-5" />
          <AlertDescription>
            Please <Button variant="link" onClick={() => navigate("/auth")} className="p-0">sign in</Button> to create school trips.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="container mx-auto my-8 px-4">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="flex-1 space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-triptrove-blue flex items-center gap-2 mb-2">
              <School className="h-8 w-8" />
              School Trip Planner
            </h1>
            <p className="text-gray-600">
              Plan educational trips for schools and colleges to explore Karnataka's rich heritage and natural beauty
            </p>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Trip Details</CardTitle>
              <CardDescription>Fill in the details for your educational trip</CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="schoolName" className="text-sm font-medium">
                      School/College Name
                    </label>
                    <Input
                      id="schoolName"
                      value={schoolName}
                      onChange={(e) => setSchoolName(e.target.value)}
                      required
                      placeholder="e.g. St. Mary's High School"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="tripName" className="text-sm font-medium">
                      Trip Name
                    </label>
                    <Input
                      id="tripName"
                      value={tripName}
                      onChange={(e) => setTripName(e.target.value)}
                      required
                      placeholder="e.g. Historical Tour 2025"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="description" className="text-sm font-medium">
                    Description & Educational Objectives
                  </label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                    placeholder="Describe the educational goals of this trip"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Start Date
                    </label>
                    <DatePicker
                      date={startDate}
                      onSelect={setStartDate}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      End Date
                    </label>
                    <DatePicker
                      date={endDate}
                      onSelect={setEndDate}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="studentCount" className="text-sm font-medium flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Number of Students
                    </label>
                    <Input
                      id="studentCount"
                      type="number"
                      min="1"
                      value={studentCount || ""}
                      onChange={(e) => setStudentCount(parseInt(e.target.value) || 0)}
                      required
                      placeholder="e.g. 40"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="transportMode" className="text-sm font-medium flex items-center gap-2">
                      <Route className="h-4 w-4" />
                      Mode of Transportation
                    </label>
                    <Select value={transportMode} onValueChange={setTransportMode} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select transportation" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bus">
                          <div className="flex items-center gap-2">
                            <Bus className="h-4 w-4" />
                            <span>School Bus</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="train">
                          <div className="flex items-center gap-2">
                            <Train className="h-4 w-4" />
                            <span>Train</span>
                          </div>
                        </SelectItem>
                        <SelectItem value="car">
                          <div className="flex items-center gap-2">
                            <Car className="h-4 w-4" />
                            <span>Private Vehicles</span>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="budget" className="text-sm font-medium">
                      Budget (₹)
                    </label>
                    <Input
                      id="budget"
                      type="number"
                      min="0"
                      value={budget}
                      onChange={(e) => setBudget(e.target.value ? parseInt(e.target.value) : "")}
                      placeholder="e.g. 50000"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="requirements" className="text-sm font-medium">
                    Special Requirements
                  </label>
                  <Textarea
                    id="requirements"
                    value={requirements}
                    onChange={(e) => setRequirements(e.target.value)}
                    rows={2}
                    placeholder="Any dietary restrictions, accessibility needs, etc."
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  type="submit" 
                  className="w-full bg-triptrove-blue hover:bg-triptrove-blue/90"
                  disabled={loading}
                >
                  {loading ? "Creating Trip..." : "Create School Trip"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
        
        <div className="flex-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Select Destinations</CardTitle>
              <CardDescription>Choose places to visit on this educational trip</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <MapBox 
                  selectedLocations={selectedPlaces} 
                  onLocationSelect={handlePlaceSelect}
                />
              </div>
              
              <div className="flex flex-wrap gap-2 mt-4">
                {selectedPlaces.map((place, index) => (
                  <Badge 
                    key={place} 
                    variant="secondary" 
                    className="pl-3 pr-2 py-1.5 flex items-center gap-1 text-sm"
                  >
                    <span className="bg-triptrove-blue text-white rounded-full h-5 w-5 inline-flex items-center justify-center text-xs mr-1">
                      {index + 1}
                    </span>
                    {place}
                    <button 
                      className="ml-1 hover:text-destructive" 
                      onClick={() => handleRemovePlace(place)}
                      type="button"
                    >
                      <Trash className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
              
              {selectedPlaces.length === 0 && (
                <Alert className="bg-blue-50 text-blue-800">
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Click on the map or select places below to add them to your trip
                  </AlertDescription>
                </Alert>
              )}
              
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-2 lg:grid-cols-3 gap-2 mt-4">
                {karnatakaTouristSpots.map((place) => (
                  <Button
                    key={place}
                    variant={selectedPlaces.includes(place) ? "default" : "outline"}
                    className={`text-sm justify-start ${
                      selectedPlaces.includes(place) 
                        ? 'bg-triptrove-blue text-white' 
                        : ''
                    }`}
                    onClick={() => handlePlaceSelect(place)}
                    type="button"
                  >
                    {selectedPlaces.includes(place) && (
                      <span className="bg-white text-triptrove-blue rounded-full h-5 w-5 flex items-center justify-center text-xs mr-1">
                        {selectedPlaces.indexOf(place) + 1}
                      </span>
                    )}
                    {place}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Educational Value</CardTitle>
              <CardDescription>Why school trips are important</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <span className="bg-green-100 text-green-800 p-1 rounded">✓</span>
                  <span>Enhances classroom learning with real-world experiences</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="bg-green-100 text-green-800 p-1 rounded">✓</span>
                  <span>Develops social skills through group activities</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="bg-green-100 text-green-800 p-1 rounded">✓</span>
                  <span>Creates lasting memories and stronger student bonds</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="bg-green-100 text-green-800 p-1 rounded">✓</span>
                  <span>Promotes cultural awareness and historical understanding</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SchoolTripPlanner;
